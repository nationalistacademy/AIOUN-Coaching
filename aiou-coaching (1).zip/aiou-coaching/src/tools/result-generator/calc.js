/* Result Generator - calculation engine (pure functions, no DOM).
   Browser: global RG      Node: require('./calc.js') */
var RG = (function () {
  var BANDS = [[80, 'A-1'], [70, 'A'], [60, 'B'], [50, 'C'], [40, 'D'], [33, 'E'], [0, 'F']];
  var GRADES = BANDS.map(function (b) { return b[1]; });

  function num(v) { if (v === '' || v === null || v === undefined) { return null; } var n = parseFloat(v); return isNaN(n) ? null : n; }
  function gradeOf(p) { for (var i = 0; i !== BANDS.length; i++) { if (p + 1e-9 >= BANDS[i][0]) { return BANDS[i][1]; } } return 'F'; }

  function evalStudent(s, cfg) {
    var total = Number(cfg.total) || 1, marks = num(s.marks), papers = num(s.papers);
    var pct = marks === null ? 0 : (marks / total) * 100;
    var okPct = pct + 1e-9 >= Number(cfg.passPct);
    var okPap = papers !== null && papers >= Number(cfg.papers);
    var pass = cfg.rule === 'papers' ? okPap : (cfg.rule === 'both' ? (okPct && okPap) : okPct);
    return { pct: pct, pass: pass, okPct: okPct, okPap: okPap, grade: pass ? gradeOf(pct) : 'F' };
  }

  /* students -> rows with evaluation + rank (competition ranking among cleared students) */
  function analyze(students, cfg) {
    var rows = students.map(function (s, i) { return { s: s, e: evalStudent(s, cfg), idx: i, rank: null }; });
    var passed = rows.filter(function (r) { return r.e.pass; }).sort(function (a, b) { return num(b.s.marks) - num(a.s.marks); });
    var last = null, rank = 0;
    passed.forEach(function (r, i) {
      var m = num(r.s.marks);
      if (m !== last) { rank = i + 1; last = m; }
      r.rank = rank;
    });
    return rows;
  }

  function summary(rows, cfg) {
    var total = rows.length, cleared = rows.filter(function (r) { return r.e.pass; });
    var gradeCounts = {}; GRADES.forEach(function (g) { gradeCounts[g] = 0; });
    rows.forEach(function (r) { gradeCounts[r.e.grade]++; });
    var sumPct = rows.reduce(function (a, r) { return a + r.e.pct; }, 0);
    var byMarks = rows.slice().sort(function (a, b) { return (num(b.s.marks) || 0) - (num(a.s.marks) || 0); });
    var toppers = cleared.slice().sort(function (a, b) { return (num(b.s.marks) - num(a.s.marks)) || cmpNat(a.s.roll, b.s.roll); }).slice(0, 3);
    return { total: total, cleared: cleared.length, failed: total - cleared.length,
      passRate: total ? (cleared.length / total) * 100 : 0, avg: total ? sumPct / total : 0,
      highest: byMarks.length ? byMarks[0] : null, lowest: byMarks.length ? byMarks[byMarks.length - 1] : null,
      toppers: toppers, gradeCounts: gradeCounts };
  }

  function cmpNat(a, b) { return String(a || '').localeCompare(String(b || ''), undefined, { numeric: true, sensitivity: 'base' }); }

  /* apply filter + sort for the report view */
  function view(rows, cfg) {
    var out = rows.filter(function (r) { return cfg.filter === 'pass' ? r.e.pass : (cfg.filter === 'fail' ? !r.e.pass : true); });
    var f = {
      roll: function (a, b) { return cmpNat(a.s.roll, b.s.roll); },
      gr: function (a, b) { return cmpNat(a.s.gr, b.s.gr); },
      name: function (a, b) { return cmpNat(a.s.name, b.s.name); },
      marks: function (a, b) { return (num(b.s.marks) - num(a.s.marks)) || cmpNat(a.s.roll, b.s.roll); },
      marksAsc: function (a, b) { return (num(a.s.marks) - num(b.s.marks)) || cmpNat(a.s.roll, b.s.roll); },
      entry: function (a, b) { return a.idx - b.idx; }
    }[cfg.sort] || null;
    if (f) { out = out.slice().sort(f); }
    return out;
  }

  /* pasted text / CSV -> students. Columns: G.R, Name, Father, Roll, Marks, [Passed papers], [S/O or D/O] */
  function parseImport(text, cfg) {
    var ok = [], bad = [], lines = String(text || '').split(/\r?\n/);
    var total = Number(cfg.total) || 0;
    lines.forEach(function (line, i) {
      if (!line.trim()) { return; }
      var d = line.indexOf('\t') !== -1 ? '\t' : (line.indexOf('|') !== -1 ? '|' : ',');
      var c = line.split(d).map(function (x) { return x.trim().replace(/^"|"$/g, ''); });
      if (i === 0 && num(c[4]) === null && /g\.?\s*r|name|roll/i.test(line)) { return; } /* header row */
      if (c.length < 5) { bad.push({ line: i + 1, why: '5 columns chahiye (G.R, Name, Father, Roll, Marks)' }); return; }
      var marks = num(c[4]);
      if (!c[1]) { bad.push({ line: i + 1, why: 'Name khali hai' }); return; }
      if (marks === null) { bad.push({ line: i + 1, why: 'Marks number nahi hain' }); return; }
      if (marks < 0 || (total && marks > total)) { bad.push({ line: i + 1, why: 'Marks 0-' + total + ' ke beech hon' }); return; }
      var rel = /^(d\/?o|f|female|girl)/i.test(c[6] || '') ? 'D/O' : 'S/O';
      ok.push({ gr: c[0], name: c[1], father: c[2], roll: c[3], marks: marks, papers: c[5] === undefined ? '' : (num(c[5]) === null ? '' : num(c[5])), rel: rel });
    });
    return { ok: ok, bad: bad };
  }

  function csvCell(v) { var s = String(v === null || v === undefined ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
  function toCsv(viewRows, cfg) {
    var dec = Number(cfg.dec);
    var head = ['S.No', 'G.R No', 'Student Name', 'Relation', 'Father Name', 'Roll No', 'Obtained Marks', 'Passed Papers', 'Percentage', 'Grade', 'Result', 'Rank'];
    var lines = [head.join(',')];
    viewRows.forEach(function (r, i) {
      lines.push([i + 1, r.s.gr, r.s.name, r.s.rel, r.s.father, r.s.roll, r.s.marks, r.s.papers, r.e.pct.toFixed(dec), r.e.grade, r.e.pass ? 'PASS' : 'FAIL', r.rank === null ? '' : r.rank].map(csvCell).join(','));
    });
    return lines.join('\r\n');
  }

  var api = { BANDS: BANDS, GRADES: GRADES, gradeOf: gradeOf, evalStudent: evalStudent, analyze: analyze, summary: summary, view: view, parseImport: parseImport, toCsv: toCsv, num: num, cmpNat: cmpNat };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  return api;
})();
