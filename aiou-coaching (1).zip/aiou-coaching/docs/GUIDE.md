# Tools ka istemal (Guide)

## 🎓 Course Advisor
1. **Qualification** chunein (Matric Science/Arts, Inter ki qismein, A-Level, DAE, AD, BA/BSc/BCom, BS/MA/MSc, MPhil/MS).
2. **Marks %** likhein, ya agar % yaad nahi to **grade / division** chunein (A+, A, B …). Dono hon to % ko tarjeeh milti hai.
3. Qualification ke mutabiq tool khud extra sawal dikhata hai:
   * Inter / A-Level / DAE / degree → **subjects** (Math, Physics, Chemistry, Biology, Computer) — Pre-Med/Pre-Eng/ICS par khud tick ho jate hain.
   * AD / 16 saal / 18 saal → **subject** (AD ya degree ka).
   * 16 / 18 saal → **CGPA**.
4. (Optional) **interest**, **study mode** (ODL / Face-to-Face), **budget**, **tarteeb**.

**Natija ke tabs:** ✅ Eligible · ⚠️ Shart ke saath (kuch confirm karna hai) · ❌ Eligible nahi (wajah ke saath) · 💸 Budget se zyada · ⬆️ Pehle se upar (aap is level se aage hain).
Neeche **guidance**: aap ki position, marks ke hisab se mashwara, pathway, top picks, fee planning, documents aur admission ke steps. **WhatsApp** button profile + shortlist ke saath message bhej deta hai.

### Tool kaise faisla karta hai
* Har program ke liye: kam az kam **level**, **marks %**, **CGPA**, zaroori **subjects**, **AD ka subject**, **qualification ki qism** (jaise "sirf BSc").
* Marks band mein hon (maslan 45–49%) aur shart 50% ho → ❌; shart 45% ho → ✅.
* Marks na likhe hon to marks-wali shart par ⚠️ aata hai.
* A-Level / DAE par ⚠️ "IBCC equivalence certificate".
* PDF ki wazeh ghaltiyan (jaise Statistics AD par Chemistry wali eligibility copy ho gayi) ⚠️ note ke saath dikhayi jati hain.

## 📅 Workshop Planner
1. **Schedule do** — teen tareeqe (portal ki table paste karna sab se aasan hai):
   * **Paste:** AIOU portal / PDF / Excel se schedule copy karke paste karein. Har line mein date (`05/12/2026`, `5-Dec-2026`), time (`10:00 AM - 12:00 PM`), workshop ka naam, venue/link — columns kisi bhi tarteeb mein. Date **DD/MM/YYYY** samjhi jati hai.
   * **Quick builder:** pehli date + time + kitni classes + rozana / peer-jumma / har hafta / khaas din + chhuttiyan.
   * **Student ID / Course code:** coach ne portal ka schedule publish kiya ho to ID ya course code (jaise `5402`) likhein, group chunein — classes khud aa jati hain (docs/WORKSHOPS.md).
2. **Reminders:** 1 din / 3 ghante / 1 ghanta / 30 / 15 minute pehle. **Quiz:** default *2nd last class*; 1st-last / 3rd-last ya off.
3. **Natija:** har class par 🧪 *Quiz option visible* aur 🏁 *Aakhri class* badge; har class ka **Google Calendar** button; quiz ka alag reminder; poora **.ics** file (Google/Apple/Outlook); **WhatsApp** message jo student ko bheja ja sakta hai.

**Zaroori:** tool AIOU portal se schedule khud *fetch nahi* karta (portal student ID / region / program se khulta hai, aur browser se doosri site ka data nahi kheencha ja sakta). Schedule aap paste karte hain. **Google Calendar** file ke andar ke alarms aksar ignore karta hai — is liye *Google-safe mode* (1 din pehle alag reminder event) ya Calendar ki default notification use karein. Quiz reminder hamesha alag event hota hai, is liye us par notification aati hai.

## 📝 Cover Sheet
Tutor/student ki details, semester (Spring/Autumn + saal), dates bharein → **PDF / JPG / PNG**. Logo built-in hai; chahein to apna upload karein. Addresses 2 (student) aur 3 (tutor) lines tak.

## 📄 Paper Generator
Course info, MCQs aur subjective sawalat add karein. Paper khud **naye pages** mein bantta hai. **Watermark** (text/image), **Urdu mode (RTL)**, aur export: PDF / JPEG / PNG / SVG (multi-page par ZIP) / Word (editable `.doc`, logo/watermark ke baghair). Sawalat browser mein auto-save hote hain.

## 📚 Solved Assignments page
Cards `data/solved-assignments.json` se, FAQ `data/faq.json` se, WhatsApp number/message `config` aur data se. SEO schema (FAQPage) khud ban jata hai.
