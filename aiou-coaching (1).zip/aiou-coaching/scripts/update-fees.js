#!/usr/bin/env node
/* Update first-semester fees in data/aiou-programs.json from a CSV.
   CSV format (no header needed; header line starting with "code" is skipped):
       code,fee            e.g.  5058,21500
   A code that appears more than once in the data (e.g. 0105) updates every row with that code.
   Usage: node scripts/update-fees.js fees.csv [--dry] */
const fs = require('fs');
const path = require('path');
const file = process.argv[2];
const dry = process.argv.includes('--dry');
if (!file) { console.error('Usage: node scripts/update-fees.js fees.csv [--dry]'); process.exit(1); }
const dataPath = path.join(__dirname, '..', 'data', 'aiou-programs.json');
const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const rows = fs.readFileSync(file, 'utf8').split(/\r?\n/).map(l => l.trim()).filter(Boolean)
  .filter(l => !/^code\b/i.test(l)).map(l => l.split(',').map(x => x.trim()));
let changed = 0; const missing = [];
for (const [code, feeRaw] of rows) {
  const fee = parseInt(String(feeRaw).replace(/[^\d]/g, ''), 10);
  if (!fee) { console.warn('Skipping bad fee for', code); continue; }
  const hits = data.filter(p => p.c === code);
  if (!hits.length) { missing.push(code); continue; }
  for (const p of hits) { if (p.f !== fee) { console.log(`${code} ${p.t}: ${p.f} -> ${fee}`); p.f = fee; changed++; } }
}
if (missing.length) console.warn('Codes not found:', missing.join(', '));
console.log(changed + ' fee(s) ' + (dry ? 'would change (dry run)' : 'updated'));
if (!dry && changed) {
  const txt = '[\n' + data.map(p => JSON.stringify(p)).join(',\n') + '\n]\n';
  fs.writeFileSync(dataPath, txt);
}
