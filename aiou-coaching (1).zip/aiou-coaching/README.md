# 🎓 AIOU Coaching Toolkit

AIOU students ke liye tools aur pages ka ek repo. Ek hi jagah se **Blogger ke liye paste-ready snippets** aur **standalone website** (GitHub Pages) dono ban jate hain.

| Tool / Page | Kya karta hai |
|---|---|
| 🎓 **Course Advisor** | Student ki qualification + marks/grade ke mutabiq AIOU ke 225 programs mein se eligible programs, fee, pathway aur guidance (Spring 2027) |
| 📅 **Workshop Planner** | AIOU portal ka schedule paste → course code / **Student ID** se classes, Google Calendar + `.ics` reminders, **quiz reminder (2nd last class)**, WhatsApp message, auto-updating calendar feeds |
| 📝 **Cover Sheet** | Assignment ka official *Mashqi Form* — PDF / JPG / PNG |
| 📄 **Paper Generator** | MCQs + subjective sawalat se multi-page A4 paper — PDF / Word / images / SVG, English + Urdu |
| 📚 **Solved Assignments page** | Programs, prices, FAQ, WhatsApp order — sab `data/` aur `config/` se generate |

## Quick start

```bash
npm test          # build + 51 tests
node scripts/roster.js roster.csv   # student roster (optional, docs/WORKSHOPS.md)
npm run build     # sirf build
```

Node 20+ chahiye, koi package install nahi karna. Build ke baad:

* `dist/blogger/*.html` → seedha Blogger mein paste karein ([docs/DEPLOY.md](docs/DEPLOY.md))
* `dist/site/` → poori standalone website (GitHub Pages par khud deploy hoti hai)

## Repo structure

```
config/
  site.json            brand, WhatsApp number, semester label, hero/CTA text, stats
  tools.json           tools ki list (hub page + build)
data/
  aiou-programs.json   AIOU ke 225 programs (fee + eligibility rules)   ← Course Advisor
  aiou-meta.json       levels, qualifications, grade bands, subjects
  solved-assignments.json   solved-assignment cards (price, bullets, WhatsApp message)
  faq.json             FAQ (page + SEO schema dono isi se)
  workshops-raw.txt    AIOU portal se paste ki hui workshop classes  ->  auto .ics feeds
  workshops.json       hand-written workshops (optional) + reminders / quiz rule
  roster.hashed.json   (roster.js banata hai) hashed Student-ID lookup - IDs/phones nahi
  source/              AIOU ki original PDF (traceability)
src/
  tools/course-advisor/   engine.js (logic) + template.html (UI)
  tools/workshop-planner/ ics.js (schedule parser + quiz rule + calendar engine) + template.html
  tools/cover-sheet/      template.html
  tools/paper-generator/  template.html
  pages/solved-assignments/  template.html, style.css, script.js
  site/index.html         hub (home) page
scripts/
  build.js             sab kuch build karta hai
  roster.js            student roster -> hashed lookup + private coach WhatsApp page
  update-fees.js       CSV se fees update
tests/                 engine + UI smoke tests
docs/                  GUIDE, DEPLOY, MAINTENANCE
.github/workflows/     GitHub Pages auto-deploy
```

## Har semester kya badalna hai
[docs/MAINTENANCE.md](docs/MAINTENANCE.md) dekhein — mukhtasar: `config/site.json` mein `semesterLabel`, `data/aiou-meta.json` mein `source`, aur nayi PDF ke mutabiq `data/aiou-programs.json` ki fees.

## Zaroori baatein
* **Course Advisor sirf rehnumai hai.** Data AIOU ki *Autumn 2026* PDF se hai (PDF khud kehti hai ke ghaltiyan ho sakti hain). Spring 2027 ki fee/eligibility aate hi update karein. Tool har result par yeh disclaimer dikhata hai.
* `config/site.json` mein stats (jaise "10,000+ Students", "98% Satisfaction") sirf wohi rakhein jo aap saabit kar sakein.
* **Student data git mein nahi jana chahiye:** `roster.csv` aur `private/` git-ignored hain. `data/roster.hashed.json` mein sirf hash keys hoti hain.
* Repo mein cover-sheet ke default data **placeholder** hain (asli student ka naam/ID nahi). Asli data repo mein commit na karein.
* License abhi `UNLICENSED` (private use). Public karna ho to apni marzi ka license chunein.
