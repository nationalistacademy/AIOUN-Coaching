const test = require('node:test');
const assert = require('node:assert');
const RG = require('../src/tools/result-generator/calc.js');

const cfg = { total: 550, passPct: 33, papers: 7, rule: 'pct', dec: 1, sort: 'roll', filter: 'all' };
const S = (o) => Object.assign({ gr: '1', name: 'A', father: 'B', roll: '1', marks: 300, papers: 7, rel: 'S/O' }, o);

test('percentage, grade bands and boundaries', () => {
  assert.strictEqual(RG.gradeOf(80), 'A-1'); assert.strictEqual(RG.gradeOf(79.99), 'A');
  assert.strictEqual(RG.gradeOf(33), 'E'); assert.strictEqual(RG.gradeOf(32.9), 'F');
  assert.strictEqual(RG.evalStudent(S({ marks: 550 }), cfg).pct, 100);
  assert.strictEqual(RG.evalStudent(S({ marks: 181.5 }), cfg).pass, true); // exactly 33%
  assert.strictEqual(RG.evalStudent(S({ marks: 181 }), cfg).pass, false);
});

test('pass rules: pct / papers / both', () => {
  const s = S({ marks: 400, papers: 5 });
  assert.strictEqual(RG.evalStudent(s, cfg).pass, true);
  assert.strictEqual(RG.evalStudent(s, Object.assign({}, cfg, { rule: 'papers' })).pass, false);
  assert.strictEqual(RG.evalStudent(s, Object.assign({}, cfg, { rule: 'both' })).pass, false);
  assert.strictEqual(RG.evalStudent(S({ marks: 100, papers: 7 }), Object.assign({}, cfg, { rule: 'both' })).pass, false);
  assert.strictEqual(RG.evalStudent(S({ marks: 400, papers: '' }), Object.assign({}, cfg, { rule: 'papers' })).pass, false);
  assert.strictEqual(RG.evalStudent(S({ marks: 100 }), cfg).grade, 'F');
});

test('rank uses competition ranking among cleared students only', () => {
  const rows = RG.analyze([S({ roll: '1', marks: 400 }), S({ roll: '2', marks: 400 }), S({ roll: '3', marks: 350 }), S({ roll: '4', marks: 100 })], cfg);
  assert.deepStrictEqual(rows.map(r => r.rank), [1, 1, 3, null]);
});

test('summary numbers, toppers and grade counts', () => {
  const rows = RG.analyze([S({ roll: '1', marks: 500 }), S({ roll: '2', marks: 300 }), S({ roll: '3', marks: 100 }), S({ roll: '4', marks: 450 })], cfg);
  const m = RG.summary(rows, cfg);
  assert.strictEqual(m.total, 4); assert.strictEqual(m.cleared, 3); assert.strictEqual(m.failed, 1);
  assert.strictEqual(Math.round(m.passRate), 75);
  assert.strictEqual(m.highest.s.marks, 500); assert.strictEqual(m.lowest.s.marks, 100);
  assert.deepStrictEqual(m.toppers.map(r => r.s.marks), [500, 450, 300]);
  assert.strictEqual(m.gradeCounts['A-1'], 2); assert.strictEqual(m.gradeCounts['F'], 1);
  assert.strictEqual(RG.summary([], cfg).total, 0);
});

test('view: natural sort by roll, marks sort, filters', () => {
  const rows = RG.analyze([S({ roll: '10', marks: 200 }), S({ roll: '9', marks: 400 }), S({ roll: '044029', marks: 100 })], cfg);
  assert.deepStrictEqual(RG.view(rows, cfg).map(r => r.s.roll), ['9', '10', '044029']);
  assert.deepStrictEqual(RG.view(rows, Object.assign({}, cfg, { sort: 'marks' })).map(r => r.s.marks), [400, 200, 100]);
  assert.strictEqual(RG.view(rows, Object.assign({}, cfg, { filter: 'fail' })).length, 1);
  assert.strictEqual(RG.view(rows, Object.assign({}, cfg, { filter: 'pass' })).length, 2);
  assert.deepStrictEqual(RG.view(rows, Object.assign({}, cfg, { sort: 'entry' })).map(r => r.idx), [0, 1, 2]);
});

test('import: tab / comma / header row / bad rows / D/O', () => {
  const txt = 'G.R,Name,Father,Roll,Marks,Papers,Rel\n1720,Ali,Ahmed,044029,276,5,\n1721,Sara,Khan,044030,300,7,D/O\n1722,,X,1,100\n1723,Bad,X,2,abc,7\n1724,Big,X,3,900,7\n';
  const r = RG.parseImport(txt, cfg);
  assert.strictEqual(r.ok.length, 2);
  assert.strictEqual(r.ok[0].roll, '044029'); // leading zeros kept
  assert.strictEqual(r.ok[1].rel, 'D/O');
  assert.strictEqual(r.bad.length, 3);
  const tab = RG.parseImport('1\tZed\tFa\t77\t333\t7', cfg);
  assert.strictEqual(tab.ok.length, 1); assert.strictEqual(tab.ok[0].marks, 333);
});

test('CSV export quotes commas and keeps computed columns', () => {
  const rows = RG.analyze([S({ name: 'Doe, John', marks: 440 })], cfg);
  const csv = RG.toCsv(RG.view(rows, cfg), cfg);
  assert.ok(csv.includes('"Doe, John"')); assert.ok(csv.includes('80.0')); assert.ok(csv.includes('PASS'));
});
