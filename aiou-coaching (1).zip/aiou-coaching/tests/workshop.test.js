const test = require('node:test');
const assert = require('node:assert');
const WS = require('../src/tools/workshop-planner/ics.js');

test('dates: ISO, DD/MM/YYYY (not MM/DD), month names, weekday prefix, invalid', () => {
  assert.strictEqual(WS.parseDate('2026-12-05').iso, '2026-12-05');
  assert.strictEqual(WS.parseDate('05/12/2026').iso, '2026-12-05');
  assert.strictEqual(WS.parseDate('5-Dec-2026').iso, '2026-12-05');
  assert.strictEqual(WS.parseDate('Sat, 5 December 2026').iso, '2026-12-05');
  assert.strictEqual(WS.parseDate('December 5, 2026').iso, '2026-12-05');
  assert.strictEqual(WS.parseDate('31/02/2026'), null);
  assert.strictEqual(WS.parseDate('hello'), null);
});

test('time ranges: 12h, 24h, inherited meridiem, "to"', () => {
  assert.deepStrictEqual(WS.parseTimeRange('10:00 AM - 12:00 PM'), { start: '10:00', end: '12:00' });
  assert.deepStrictEqual(WS.parseTimeRange('10:00-12:00 PM'), { start: '10:00', end: '12:00' });
  assert.deepStrictEqual(WS.parseTimeRange('2:00 - 4:00 PM'), { start: '14:00', end: '16:00' });
  assert.deepStrictEqual(WS.parseTimeRange('14:30'), { start: '14:30', end: null });
  assert.deepStrictEqual(WS.parseTimeRange('9am to 11am'), { start: '09:00', end: '11:00' });
  assert.strictEqual(WS.parseTimeRange('abc'), null);
});

test('paste parser: header row, tab/comma, any column order, bad lines', () => {
  const txt = 'Date,Time,Workshop,Venue\n05/12/2026,10:00 AM - 12:00 PM,BS English,Zoom link\nSun 06 Dec 2026,10:00-12:00,BS English,Zoom link\nnot a date,10:00,X,Y\n07/12/2026,,BS English,Z';
  const r = WS.parseSchedule(txt);
  assert.strictEqual(r.sessions.length, 2);
  assert.strictEqual(r.sessions[0].title, 'BS English'); assert.strictEqual(r.sessions[0].venue, 'Zoom link');
  assert.strictEqual(r.bad.length, 2);
  const swapped = WS.parseSchedule('BS Math\t10:00 AM\t12/12/2026');
  assert.strictEqual(swapped.sessions[0].date, '2026-12-12'); assert.strictEqual(swapped.sessions[0].title, 'BS Math');
  assert.strictEqual(WS.parseSchedule('12/12/2026 BS', { start: '09:00' }).sessions.length, 0); // no delimiter + no time cell is not guessed
});

test('quick builder patterns', () => {
  const base = { title: 'W', start: '10:00', startDate: '2026-12-05' }; // Saturday
  assert.deepStrictEqual(WS.generateSessions(Object.assign({ pattern: 'daily', count: 3 }, base)).map(s => s.date), ['2026-12-05', '2026-12-06', '2026-12-07']);
  assert.deepStrictEqual(WS.generateSessions(Object.assign({ pattern: 'weekly', count: 3 }, base)).map(s => s.date), ['2026-12-05', '2026-12-12', '2026-12-19']);
  assert.deepStrictEqual(WS.generateSessions(Object.assign({ pattern: 'weekdays', count: 3 }, base)).map(s => s.date), ['2026-12-07', '2026-12-08', '2026-12-09']);
  assert.deepStrictEqual(WS.generateSessions(Object.assign({ pattern: 'custom', days: [6, 0], count: 4 }, base)).map(s => s.date), ['2026-12-05', '2026-12-06', '2026-12-12', '2026-12-13']);
  assert.deepStrictEqual(WS.generateSessions(Object.assign({ pattern: 'daily', count: 3, skip: ['2026-12-06'] }, base)).map(s => s.date), ['2026-12-05', '2026-12-07', '2026-12-08']);
});

const mk = (n, title) => WS.generateSessions({ title: title || 'BS English', start: '10:00', end: '12:00', startDate: '2026-12-05', pattern: 'daily', count: n });

test('quiz rule: 2nd last class by default; configurable; edge cases', () => {
  const quizIdx = (n, from) => WS.plan(mk(n), { quizFromEnd: from })[0].sessions.findIndex(s => s.quiz) + 1;
  assert.strictEqual(quizIdx(10), 9); assert.strictEqual(quizIdx(5), 4); assert.strictEqual(quizIdx(2), 1);
  assert.strictEqual(quizIdx(1), 0);              // single class: no quiz
  assert.strictEqual(quizIdx(10, 3), 8); assert.strictEqual(quizIdx(10, 1), 10); assert.strictEqual(quizIdx(10, 0), 0);
  const pl = WS.plan(mk(4).concat(mk(6, 'BS Urdu')), {});
  assert.strictEqual(pl.length, 2);                                  // grouped per workshop
  assert.strictEqual(pl[0].sessions.filter(s => s.quiz).length, 1);
  assert.strictEqual(pl[1].sessions[4].quiz, true);                  // 5th of 6
  assert.strictEqual(pl[1].sessions[5].last, true);
});

test('Karachi (UTC+5) is converted to UTC correctly, incl. past-midnight and end time', () => {
  assert.strictEqual(WS.fmtUtc(WS.utcMs('2026-12-05', '10:00')), '20261205T050000Z');
  assert.strictEqual(WS.fmtUtc(WS.utcMs('2026-12-05', '03:30')), '20261204T223000Z');
  const s = WS.plan(WS.generateSessions({ title: 'W', start: '10:00', startDate: '2026-12-05', pattern: 'daily', count: 1 }), { durationMin: 90 })[0].sessions[0];
  assert.strictEqual(s.end, '11:30'); assert.strictEqual(s.endMs - s.startMs, 90 * 60000);
});

test('events: session + quiz event + Google-safe reminder events', () => {
  const pl = WS.plan(mk(5), {});
  assert.strictEqual(WS.events(pl, { reminders: [60] }).length, 5 + 1);
  const ev = WS.events(pl, { reminders: [60], safe: [1440] });
  assert.strictEqual(ev.length, 5 + 1 + 5);
  const quiz = ev.find(e => e.kind === 'quiz');
  assert.ok(/QUIZ/.test(quiz.summary)); assert.strictEqual(quiz.start, pl[0].sessions[3].startMs);
  assert.strictEqual(new Set(ev.map(e => e.uid)).size, ev.length, 'unique uids');
  assert.deepStrictEqual(WS.events(pl, { reminders: [60] }).map(e => e.uid), WS.events(pl, { reminders: [15] }).map(e => e.uid), 'uids stable across settings');
});

test('ICS: valid structure, CRLF, escaping, folding <= 75 octets, alarms', () => {
  const pl = WS.plan(WS.generateSessions({ title: 'Workshop; with, special \\ chars \u062a\u0633\u062a', venue: 'Room 1, Block A', start: '10:00', end: '12:00', startDate: '2026-12-05', pattern: 'daily', count: 3 }), {});
  const ics = WS.buildIcs(WS.events(pl, { reminders: [1440, 60, 15], brand: 'Taleemwaly' }), { now: new Date('2026-10-30T00:00:00Z'), name: 'Test' });
  assert.ok(ics.startsWith('BEGIN:VCALENDAR\r\n') && ics.endsWith('END:VCALENDAR\r\n'));
  assert.ok(!/[^\r]\n/.test(ics), 'only CRLF line breaks');
  const count = (re) => (ics.match(re) || []).length;
  assert.strictEqual(count(/BEGIN:VEVENT/g), count(/END:VEVENT/g)); assert.strictEqual(count(/BEGIN:VEVENT/g), 4);
  assert.strictEqual(count(/BEGIN:VALARM/g), 3 * 3 + 2); // 3 sessions x3 + quiz x2
  assert.ok(ics.includes('TRIGGER:-PT1440M') && ics.includes('TRIGGER:PT0S'));
  ics.split('\r\n').forEach(l => assert.ok(Buffer.byteLength(l) <= 75, 'line too long: ' + l.length));
  assert.ok(ics.includes('\\;') && ics.includes('\\,') && ics.includes('\\\\'));
  assert.ok(ics.includes('DTSTART:20261205T050000Z') && ics.includes('DTSTAMP:20261030T000000Z'));
});

test('Google Calendar link and WhatsApp message', () => {
  const pl = WS.plan(mk(3), {});
  const link = WS.googleLink(WS.events(pl, {})[0]);
  assert.ok(link.startsWith('https://calendar.google.com/calendar/render?action=TEMPLATE&text='));
  assert.ok(link.includes('dates=20261205T050000Z/20261205T070000Z') && link.includes('ctz=Asia%2FKarachi'));
  const msg = WS.message(pl, { student: 'Ali', reminders: [1440, 60], brand: 'Taleemwaly' });
  assert.ok(msg.includes('Sat, 05 Dec 2026') && msg.includes('10:00 AM - 12:00 PM') && msg.includes('QUIZ option visible') && msg.includes('1 din, 1 ghanta'));
});

/* ---------- AIOU portal paste format ---------- */
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORTAL = fs.readFileSync(path.join(__dirname, 'fixtures/portal-paste.txt'), 'utf8');

test('datetime cells: "Tuesday, July 7, 2026 3:40 PM"', () => {
  assert.deepStrictEqual(WS.parseDateTime('Tuesday, July 7, 2026 3:40 PM'), { date: WS.parseDate('2026-07-07'), hm: '15:40' });
  assert.strictEqual(WS.parseDateTime('Monday, August 17, 2026 8:30 PM').hm, '20:30');
  assert.strictEqual(WS.parseDateTime('Friday, July 3, 2026 2:00 PM').date.iso, '2026-07-03');
  assert.strictEqual(WS.parseDateTime('nonsense'), null);
});

test('real AIOU portal paste: 42 classes, 7 course-groups, Friday short class, no lines lost', () => {
  const r = WS.parseSchedule(PORTAL);
  assert.strictEqual(r.bad.length, 0); assert.strictEqual(r.sessions.length, 42);
  const pl = WS.plan(r.sessions, {});
  assert.strictEqual(pl.length, 7);
  const w = pl.find(x => x.code === '5402');
  assert.deepStrictEqual([w.group, w.batch, w.title, w.sessions.length], ['G909', '16BH', '5402 (G909)', 6]);
  assert.deepStrictEqual(w.sessions.map(s => s.date), ['2026-07-06', '2026-07-07', '2026-07-08', '2026-07-09', '2026-07-10', '2026-07-11']); // sorted although pasted shuffled
  assert.deepStrictEqual([w.sessions[0].start, w.sessions[0].end], ['15:40', '17:40']);
  assert.deepStrictEqual([w.sessions[4].start, w.sessions[4].end], ['16:20', '18:00']);   // Friday is shorter
  assert.strictEqual(w.sessions.findIndex(s => s.quiz), 4);                               // 5th of 6 = 2nd last
  assert.strictEqual(WS.fmtUtc(w.sessions[0].startMs), '20260706T104000Z');               // 3:40 PM PKT = 10:40 UTC
});

test('portal paste also works when tabs were turned into spaces (copied from chat/Word)', () => {
  const spaced = PORTAL.split('\n').slice(0, 3).map(l => l.replace(/\t/g, '  ')).join('\n');
  const r = WS.parseSchedule(spaced);
  assert.strictEqual(r.sessions.length, 3); assert.strictEqual(r.sessions[0].code, '5402'); assert.strictEqual(r.sessions[0].start, '15:40'); assert.strictEqual(r.sessions[0].end, '17:40');
});

test('comment lines (#) and blank lines are ignored', () => {
  const r = WS.parseSchedule('# note\n\n' + PORTAL.split('\n')[0]);
  assert.strictEqual(r.sessions.length, 1); assert.strictEqual(r.bad.length, 0);
});

test('SHA-256 matches node crypto (incl. long input) and the iterated ID key', () => {
  const hex = u8 => Buffer.from(u8).toString('hex');
  for (const m of ['', 'abc', 'a'.repeat(55), 'a'.repeat(56), 'a'.repeat(64), 'salt:0001189718'])
    assert.strictEqual(hex(WS.sha256(Buffer.from(m))), crypto.createHash('sha256').update(m).digest('hex'), m.length + ' chars');
  let h = crypto.createHash('sha256').update('abc123:0001189718').digest();
  for (let i = 1; i < 500; i++) h = crypto.createHash('sha256').update(h).digest();
  assert.strictEqual(WS.idKey('000-118 9718', 'abc123', 500), h.toString('hex').slice(0, 16)); // normalised ID
  assert.notStrictEqual(WS.idKey('1', 's', 5), WS.idKey('2', 's', 5));
});

test('phone numbers become wa.me format', () => {
  assert.strictEqual(WS.normPhone('0300-1234567'), '923001234567');
  assert.strictEqual(WS.normPhone('+92 300 1234567'), '923001234567');
  assert.strictEqual(WS.normPhone('3001234567'), '923001234567');
});
