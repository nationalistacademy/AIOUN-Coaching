# Changelog

## 1.2.0
* Workshop Planner understands the AIOU portal paste (`course|group|batch`, `Weekday, Month D, YYYY h:mm AM`), also when tabs became spaces.
* `data/workshops-raw.txt` -> one `.ics` feed per course-group (+ all.ics), Google-safe day-before reminders in feeds.
* Student-ID lookup via hashed roster (`scripts/roster.js`), personal feeds `u-<key>.ics`, private coach WhatsApp reminder page.
* 51 tests.

## 1.1.0
* Workshop Planner: schedule paste/quick builder, Google Calendar links, `.ics` (Google/Apple/Outlook), WhatsApp message, quiz reminder on 2nd last class, published schedules + auto-updating `.ics` feeds.
* Result Generator: calculation engine + tests (UI pending).
* Build output is pure ASCII (Blogger turns non-ASCII into `&#NNNN;`, which broke JS strings).
* Tests isolated with env overrides (`AIOU_DIST`, `AIOU_SITE`, `AIOU_WORKSHOPS`).

## 1.0.0
* Course Advisor (Spring 2027): 225 AIOU programs, eligibility engine, guidance, WhatsApp share.
* Cover Sheet generator: Blogger-ready, A4 pixel layout, PDF/JPG/PNG.
* Paper Generator: multi-page pagination, watermark preview, Urdu mode, ZIP exports, auto-save.
* Solved Assignments page: data-driven cards/FAQ/schema.
* Build pipeline (Blogger snippets + static site), tests, GitHub Pages workflow.
