#!/usr/bin/env node
/* Builds paste-ready Blogger snippets (dist/blogger) and a standalone static site (dist/site).
   Usage: node scripts/build.js        (no dependencies) */
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const P = (...a) => path.resolve(ROOT, ...a);
/* Optional env overrides (used by tests so they never touch the real repo files): AIOU_DIST, AIOU_SITE, AIOU_WORKSHOPS */
const DIST = process.env.AIOU_DIST || 'dist';
const read = f => fs.readFileSync(P(f), 'utf8');
const readJson = f => JSON.parse(read(f));
const write = (f, s) => { fs.mkdirSync(path.dirname(P(f)), { recursive: true }); fs.writeFileSync(P(f), s); };
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const jsJson = o => JSON.stringify(o).replace(/&/g, '\\u0026').replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

function fill(tpl, vars, name) {
  return tpl.replace(/\{\{([A-Z_]+)\}\}/g, (m, k) => {
    if (!(k in vars)) throw new Error(`[${name}] unknown placeholder {{${k}}}`);
    return vars[k];
  });
}


/* Blogger rewrites every non-ASCII character into a numeric entity (&#8212;). That is harmless in HTML text but
   shows up literally inside JavaScript strings. So the final output is made 100% ASCII, per context:
   <script> -> \uXXXX   <style> -> \XXXXXX   everything else -> &#xXXXX;  */
function asciiSafe(html) {
  const jsEsc = t => t.replace(/[^\x00-\x7f]/g, c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
  const cssEsc = t => Array.from(t).map(ch => ch.codePointAt(0) > 127 ? '\\' + ch.codePointAt(0).toString(16) + ' ' : ch).join('');
  const htmlEsc = t => Array.from(t).map(ch => ch.codePointAt(0) > 127 ? '&#x' + ch.codePointAt(0).toString(16) + ';' : ch).join('');
  return html.split(/(<script\b[\s\S]*?<\/script>|<style\b[\s\S]*?<\/style>)/g).map(seg => {
    if (/^<script\b/.test(seg)) return jsEsc(seg);
    if (/^<style\b/.test(seg)) return cssEsc(seg);
    return htmlEsc(seg);
  }).join('');
}

/* ---------- inputs ---------- */
const site = readJson(process.env.AIOU_SITE || 'config/site.json');
const toolsCfg = readJson('config/tools.json').tools;
const programs = readJson('data/solved-assignments.json');
const faq = readJson('data/faq.json');
const aiou = readJson('data/aiou-programs.json');
const meta = readJson('data/aiou-meta.json');
const WSX = require('../src/tools/workshop-planner/ics.js');
const WL = require('./lib/workshops.js');
const loaded = WL.load({ raw: P(process.env.AIOU_RAW || 'data/workshops-raw.txt'), manual: P(process.env.AIOU_WORKSHOPS || 'data/workshops.json') });
const wsData = loaded.manual;
const rosterFile = P(process.env.AIOU_ROSTER || 'data/roster.hashed.json');
const roster = fs.existsSync(rosterFile) ? JSON.parse(fs.readFileSync(rosterFile, 'utf8')) : null;

if (!/^\d{8,15}$/.test(site.whatsapp)) throw new Error('config/site.json: whatsapp must be digits only (e.g. 923001234567)');
if (!/^[\w .&-]+$/.test(site.brand)) throw new Error('config/site.json: brand has unsupported characters');
const wa = (msg) => `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(msg)}`;
const stripTags = s => s.replace(/<[^>]+>/g, '');

/* ---------- shared pieces ---------- */
const engine = read('src/tools/course-advisor/engine.js');
const eStr = []; const eIdx = new Map();
const aiouSlim = aiou.map(p => {
  const q = Object.assign({}, p);
  if (!eIdx.has(p.e)) { eIdx.set(p.e, eStr.length); eStr.push(p.e); }
  q.e = eIdx.get(p.e);
  return q;
});

/* published workshops (portal paste + manual) -> compact form for the planner */
const published = loaded.items.map(it => ({ slug: it.slug, title: it.title, code: it.code, group: it.group, batch: it.batch, mode: it.mode, venue: it.venue,
  s: it.sessions.map(x => [x.date, x.start, x.end || '', x.venue || '']) }));
if (loaded.bad.length) console.warn('WARNING data/workshops-raw.txt: ' + loaded.bad.length + ' line(s) skipped, e.g. line ' + loaded.bad[0].line + ': ' + loaded.bad[0].why);

function toolVars() {
  return {
    LOGO: read('assets/logo.b64').trim(),
    ENGINE: engine, META: jsJson(meta), ESTR: jsJson(eStr), DATA: jsJson(aiouSlim),
    WHATSAPP: site.whatsapp, BRAND: site.brand, SOURCE: meta.source,
    WS_ENGINE: read('src/tools/workshop-planner/ics.js'),
    PUBLISHED: jsJson({ base: site.calendarBaseUrl || '', items: published, roster: roster ? { salt: roster.salt, rounds: roster.rounds, entries: roster.entries } : null })
  };
}

function solvedPage(target) {
  const advisorUrl = target === 'blogger' ? `${site.siteUrl}/p/course-advisor.html` : '../tools/course-advisor/';
  const stats = site.stats.map(s => {
    const attrs = s.count ? ` data-count="${s.count}" data-suffix="${esc(s.suffix || '')}"` : '';
    return `        <div class="sa-stat"><span class="sa-stat-num"${attrs}>${esc(s.num)}</span><span class="sa-stat-lbl">${esc(s.label)}</span></div>`;
  }).join('\n');
  const cards = programs.map(p => {
    const badge = p.badge.type ? `sa-card-badge ${p.badge.type}` : 'sa-card-badge';
    return `      <article class="sa-card${p.featured ? ' sa-card-featured' : ''}" data-cat="${esc(p.cat)}">
        <div class="sa-card-head"><div class="sa-card-icon">${p.icon}</div><span class="${badge}">${esc(p.badge.text)}</span></div>
        <h3>${esc(p.title)}</h3>
        <span class="sa-card-code">Course codes: <b>${esc(p.codes)}</b></span>
        <p>${esc(p.desc)}</p>
        <ul class="sa-card-list">${p.bullets.map(b => `<li>${esc(b)}</li>`).join('')}</ul>
        <div class="sa-card-foot">
          <div class="sa-card-price">${esc(p.price)}<small>${esc(p.unit)}</small></div>
          <a class="sa-card-btn" href="${wa(p.message)}" target="_blank" rel="noopener">Order →</a>
        </div>
      </article>`;
  }).join('\n');
  const faqHtml = faq.map(f => `      <details class="sa-faq-item"><summary><span>${esc(f.q)}</span><span class="sa-faq-plus" aria-hidden="true">+</span></summary><div class="sa-faq-content"><p>${f.a}</p></div></details>`).join('\n');
  const schema = jsJson({
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'CollectionPage', name: 'Solved Assignments — AIOU', description: site.hero.lead, url: site.pageUrl, inLanguage: 'en-PK',
        isPartOf: { '@type': 'WebSite', name: site.brand, url: site.siteUrl } },
      { '@type': 'FAQPage', mainEntity: faq.map(f => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: stripTags(f.a) } })) }
    ]
  });
  return fill(read('src/pages/solved-assignments/template.html'), {
    STYLE: read('src/pages/solved-assignments/style.css'), SCRIPT: read('src/pages/solved-assignments/script.js'),
    SEMESTER_LABEL: esc(site.semesterLabel), HERO_TITLE: esc(site.hero.title), HERO_LEAD: esc(site.hero.lead),
    WA_ORDER_URL: wa('Solved assignments chahiye'), WA_CTA_URL: wa(site.cta.message),
    ADVISOR_BTN: `<a class="sa-btn sa-btn-ghost" href="${advisorUrl}">🎓 Course Advisor</a>`,
    STATS: stats, CARDS: cards, FAQ: faqHtml, CTA_TITLE: esc(site.cta.title), CTA_TEXT: esc(site.cta.text), SCHEMA: schema
  }, 'solved-assignments');
}

const SHELL = (title, desc, body, depth) => `<!doctype html>
<html lang="ur"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} | ${esc(site.brand)}</title><meta name="description" content="${esc(desc)}">
<style>
:root{--bs-body-color:#4a4a4a;--jt-heading-color:#111;--bs-body-bg:#fff;--jt-bg-light:#f3f7f9;--jt-border-light:#e6e6e6;--jt-archive-bg:#fff}
@media(prefers-color-scheme:dark){:root{--bs-body-color:#c9c9c9;--jt-heading-color:#f3f3f3;--bs-body-bg:#14171a;--jt-bg-light:#1c2024;--jt-border-light:#2b3036;--jt-archive-bg:#1b1f23}}
body{margin:0;padding:16px;background:var(--bs-body-bg);color:var(--bs-body-color);font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;line-height:1.6}
.topnav{max-width:1160px;margin:0 auto 6px;font-size:14px}.topnav a{color:#f67938;text-decoration:none;font-weight:700}
</style></head><body>
<script>if(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches){document.documentElement.classList.add('dark-mode')}</script>
${depth ? `<div class="topnav"><a href="${depth}">← ${esc(site.brand)} Home</a></div>` : ''}
${body}
</body></html>
`;

/* ---------- build ---------- */
const out = [];
function emit(file, content) {
  file = file.replace(/^dist\//, DIST.replace(/\/$/, '') + '/');
  if (file.endsWith('.html')) content = asciiSafe(content);
  if (content.includes(']]>') && !content.includes('//]]>')) throw new Error(file + ': stray ]]>');
  write(file, content); out.push([file, Buffer.byteLength(content)]);
}

fs.rmSync(P(DIST), { recursive: true, force: true });
const tv = toolVars();
const cards = [];

for (const t of toolsCfg) {
  const body = fill(read(t.template), tv, t.slug);
  emit(`dist/blogger/${t.slug}.html`, body);
  emit(`dist/site/tools/${t.slug}/index.html`, SHELL(t.title, t.desc, body, '../../'));
  cards.push(`    <a class="hub-card" href="tools/${t.slug}/"><div class="hub-ic">${t.icon}</div><h2>${esc(t.title)}</h2><p>${esc(t.desc)}</p><span class="hub-go">Kholein →</span></a>`);
}
const feedOpts = { reminders: wsData.reminders || [1440, 60, 15], safe: wsData.safe === undefined ? [1440] : wsData.safe, brand: site.brand };
const quizFromEnd = wsData.quizFromEnd === undefined ? 2 : wsData.quizFromEnd;
const evBySlug = {}, allEv = [];
for (const it of loaded.items) {
  const ev = WSX.events(WSX.plan(WL.toSessions(it), { quizFromEnd }), feedOpts);
  evBySlug[it.slug] = ev; allEv.push(...ev);
  emit(`dist/site/calendar/${it.slug}.ics`, WSX.buildIcs(ev, { name: it.title }));
}
if (loaded.items.length) emit('dist/site/calendar/all.ics', WSX.buildIcs(allEv, { name: site.brand + ' - AIOU Workshops' }));
/* one private-ish feed per roster student: URL contains an iterated-hash key, not the student ID */
if (roster) {
  for (const key of Object.keys(roster.entries)) {
    if (!/^[0-9a-f]{16}$/.test(key)) throw new Error('data/roster.hashed.json: bad key ' + key);
    const mine = loaded.items.filter(it => roster.entries[key].some(p => p[0] === it.code && p[1] === it.group));
    if (mine.length) emit(`dist/site/calendar/u-${key}.ics`, WSX.buildIcs(mine.flatMap(it => evBySlug[it.slug]), { name: site.brand + ' - Meri workshops' }));
  }
}
const solvedB = solvedPage('blogger');
emit('dist/blogger/solved-assignments.html', solvedB);
emit('dist/site/solved-assignments/index.html', SHELL('AIOU Solved Assignments', site.hero.lead, solvedPage('site'), '../'));
cards.push(`    <a class="hub-card" href="solved-assignments/"><div class="hub-ic">📚</div><h2>Solved Assignments</h2><p>Matric se Master tak — programs, prices aur order.</p><span class="hub-go">Kholein →</span></a>`);

const hub = fill(read('src/site/index.html'), { BRAND: esc(site.brand), SEMESTER_LABEL: esc(site.semesterLabel), TOOL_CARDS: cards.join('\n'), WA_URL: wa('Assalam o Alaikum, mujhe guidance chahiye') }, 'hub');
emit('dist/site/index.html', SHELL(site.brand + ' — AIOU Coaching & Tools', site.hero.lead, hub, ''));
emit('dist/site/.nojekyll', '');

console.log('Build OK');
for (const [f, n] of out) console.log(`  ${f.padEnd(52)} ${(n / 1024).toFixed(1).padStart(7)} KB`);
const big = out.filter(([f, n]) => f.startsWith('dist/blogger') && n > 180 * 1024);
if (big.length) console.warn('WARNING: large Blogger snippet(s): ' + big.map(b => b[0]).join(', ') + ' — use a Blogger *Page*, not a gadget.');
