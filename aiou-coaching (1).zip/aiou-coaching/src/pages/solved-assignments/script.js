(function(){
  var d = document;
  var filters = d.querySelectorAll('.sa-filter');
  var cards = d.querySelectorAll('.sa-card[data-cat]');
  filters.forEach(function(btn){
    btn.addEventListener('click', function(){
      filters.forEach(function(b){ b.classList.remove('active'); });
      this.classList.add('active');
      var cat = this.getAttribute('data-cat');
      cards.forEach(function(card){
        var c = card.getAttribute('data-cat');
        card.style.display = (cat === 'all' || c === cat || c === 'all') ? 'flex' : 'none';
      });
    });
  });

  var counters = d.querySelectorAll('.sa-stat-num[data-count]');
  function animateCounter(el){
    var target = parseInt(el.getAttribute('data-count'), 10);
    var suffix = el.getAttribute('data-suffix') || '';
    var start = null, duration = 1500;
    function step(ts){
      if(!start) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      el.textContent = Math.floor((1 - Math.pow(1 - p, 3)) * target).toLocaleString() + suffix;
      if(p < 1) requestAnimationFrame(step); else el.textContent = target.toLocaleString() + suffix;
    }
    requestAnimationFrame(step);
  }
  if('IntersectionObserver' in window){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(e){ if(e.isIntersecting){ animateCounter(e.target); io.unobserve(e.target); } });
    }, { threshold: 0.3 });
    counters.forEach(function(c){ io.observe(c); });
  } else { counters.forEach(animateCounter); }

  function applyDarkFix(){
    var isDark = d.documentElement.classList.contains('dark-mode') || d.body.classList.contains('dark-mode');
    if(isDark) d.documentElement.classList.add('dark-mode');
  }
  applyDarkFix();
  if(typeof MutationObserver !== 'undefined'){
    var obs = new MutationObserver(function(m){ m.forEach(function(x){ if(x.attributeName === 'class') applyDarkFix(); }); });
    obs.observe(d.documentElement, { attributes: true });
    obs.observe(d.body, { attributes: true });
  }
})();
