const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const os = require('os');
const { execFileSync } = require('child_process');
const ROOT = path.join(__dirname, '..');

class El {
  constructor(tag) { this.tag = tag; this.children = []; this.listeners = {}; this.attrs = {}; this.style = {}; this.value = ''; this.checked = false; this._cls = new Set(); this._text = ''; this._html = ''; }
  get className() { return [...this._cls].join(' '); }
  set className(v) { this._cls = new Set(String(v).split(/\s+/).filter(Boolean)); }
  get classList() { const s = this._cls; return { add: c => s.add(c), remove: c => s.delete(c), toggle: c => (s.has(c) ? s.delete(c) : s.add(c)), contains: c => s.has(c) }; }
  appendChild(c) { this.children.push(c); return c; }
  get firstChild() { return this.children[0] || null; }
  set innerHTML(v) { this._html = v; if (v === '') this.children = []; }
  get innerHTML() { return this._html; }
  set textContent(v) { this._text = v; } get textContent() { return this._text; }
  addEventListener(e, fn) { (this.listeners[e] = this.listeners[e] || []).push(fn); }
  fire(e) { (this.listeners[e] || []).forEach(fn => fn.call(this, { target: this })); }
  setAttribute(k, v) { this.attrs[k] = v; } getAttribute(k) { return this.attrs[k]; }
  getElementsByTagName(t) { const o = []; (function w(n) { n.children.forEach(c => { if (c.tag === t) o.push(c); w(c); }); })(this); return o; }
  all(pred) { const o = []; (function w(n) { n.children.forEach(c => { if (pred(c)) o.push(c); w(c); }); })(this); return o; }
}
function boot(dist) {
  const html = fs.readFileSync(path.join(dist || path.join(ROOT, 'dist'), 'blogger/workshop-planner.html'), 'utf8');
  const ids = {}; for (const m of html.matchAll(/<(\w+)[^>]*\sid="([\w-]+)"/g)) ids[m[2]] = new El(m[1]);
  ids['s-quiz'].value = '2'; ids['s-dur'].value = '120'; ids['b-pattern'].value = 'daily'; ids['b-start'].value = '10:00'; ids['b-end'].value = '12:00'; ids['b-count'].value = '8';
  const doc = { readyState: 'complete', getElementById: id => ids[id] || null, createElement: t => new El(t), body: new El('body') };
  const ctx = { document: doc, window: { addEventListener() {}, prompt() {} }, navigator: {}, console, encodeURIComponent, parseInt, JSON, Math, Date, Array, Set, setTimeout };
  vm.createContext(ctx); const errors = [];
  for (const m of html.matchAll(/<script(?![^>]*\bsrc=)(?![^>]*ld\+json)[^>]*>([\s\S]*?)<\/script>/g)) { try { vm.runInContext(m[1], ctx); } catch (e) { errors.push(e); } }
  return { ids, errors };
}
const sessions = out => out.all(c => c.className.split(' ').includes('wp-s'));

test('planner boots, sample schedule renders with quiz on 2nd last class', () => {
  const { ids, errors } = boot();
  assert.deepStrictEqual(errors, []);
  assert.ok(ids['wp-out'].children[0].className.includes('wp-intro'));
  ids['wp-sample'].fire('click');
  const rows = sessions(ids['wp-out']);
  assert.strictEqual(rows.length, 5);
  const quiz = rows.map((r, i) => r.className.includes('quiz') ? i + 1 : 0).filter(Boolean);
  assert.deepStrictEqual(quiz, [4]);                       // 5 classes -> 4th is 2nd last
  assert.ok(rows[4].className.includes('last'));
  const links = ids['wp-out'].all(c => c.tag === 'a' && String(c.href).startsWith('https://calendar.google.com/'));
  assert.strictEqual(links.length, 5 + 1);                  // 5 sessions + 1 quiz reminder
  assert.ok(ids['wp-parse-msg'].textContent.includes('5 classes'));
});

test('settings re-render: quiz rule, bad paste, quick builder', () => {
  const { ids } = boot();
  ids['wp-sample'].fire('click');
  ids['s-quiz'].value = '1'; ids['s-quiz'].fire('change');
  assert.deepStrictEqual(sessions(ids['wp-out']).map((r, i) => r.className.includes('quiz') ? i + 1 : 0).filter(Boolean), [5]);
  ids['s-quiz'].value = '0'; ids['s-quiz'].fire('change');
  assert.strictEqual(sessions(ids['wp-out']).filter(r => r.className.includes('quiz')).length, 0);
  ids['wp-text'].value = 'garbage'; ids['wp-parse'].fire('click');
  assert.ok(ids['wp-parse-msg'].className.includes('err'));
  assert.ok(ids['wp-out'].children[0].className.includes('wp-intro'));
  ids['wp-tab-build'].fire('click');
  assert.strictEqual(ids['wp-p-build'].style.display, 'block'); assert.strictEqual(ids['wp-p-paste'].style.display, 'none');
  ids['b-gen'].fire('click'); assert.ok(ids['b-msg'].className.includes('err'));       // date missing
  ids['b-title'].value = 'BS Math'; ids['b-date'].value = '2026-12-05'; ids['b-gen'].fire('click');
  assert.strictEqual(sessions(ids['wp-out']).length, 8);
  assert.strictEqual(sessions(ids['wp-out']).filter(r => r.className.includes('quiz')).length, 0); // quiz still off
  ids['s-quiz'].value = '2'; ids['s-quiz'].fire('change');
  assert.strictEqual(sessions(ids['wp-out']).findIndex(r => r.className.includes('quiz')), 6);
});

const RB = require('../scripts/roster.js');
const PORTAL = path.join(ROOT, 'tests/fixtures/portal-paste.txt');
const ROSTER_CSV = 'student_id,name,phone,course_code,group\n0000000001,Ali Khan,0300-0000001,5402,G909\n0000000001,Ali Khan,0300-0000001,8422,G1265\n0000000002,Sara Ahmed,0300-0000002,5402,G909\n';

/* builds into a temp dir with env overrides - never touches repo files */
function tmpBuild(o) {
  o = o || {};
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aiou-')), dist = path.join(dir, 'dist');
  const wf = path.join(dir, 'workshops.json'), sf = path.join(dir, 'site.json'), rf = path.join(dir, 'roster.hashed.json');
  fs.writeFileSync(wf, JSON.stringify(o.workshops || { workshops: [] }));
  const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config/site.json'), 'utf8')); cfg.calendarBaseUrl = o.base === undefined ? 'https://example.github.io/aiou' : o.base; fs.writeFileSync(sf, JSON.stringify(cfg));
  const env = Object.assign({}, process.env, { AIOU_DIST: dist, AIOU_SITE: sf, AIOU_WORKSHOPS: wf, AIOU_RAW: o.raw || path.join(dir, 'none.txt'), AIOU_ROSTER: rf });
  if (o.roster) { const r = RB.buildRoster(o.roster, null, 300); fs.writeFileSync(rf, JSON.stringify({ salt: r.salt, rounds: r.rounds, entries: r.entries })); o.rosterObj = r; }
  execFileSync('node', [path.join(ROOT, 'scripts/build.js')], { stdio: 'pipe', env });
  return dist;
}
const find = (ids, pred) => ids['f-list'].all(pred);
const webcal = ids => find(ids, c => c.tag === 'a' && String(c.href).startsWith('webcal://'));

test('portal paste -> one .ics feed per course-group, quiz on the 2nd last class, Google-safe reminders', () => {
  const dist = tmpBuild({ raw: PORTAL });
  const cal = fs.readdirSync(path.join(dist, 'site/calendar')).sort();
  assert.deepStrictEqual(cal, ['all.ics', 'c-5402-g909-16bh.ics', 'c-8422-g1265-16bh.ics', 'c-8427-g1275-16bh.ics', 'c-8430-g1280-16bh.ics', 'c-8438-g1291-16bh.ics', 'c-9302-g2195-16bh.ics', 'c-9488-g2579-16bh.ics']);
  const ics = fs.readFileSync(path.join(dist, 'site/calendar/c-5402-g909-16bh.ics'), 'utf8');
  assert.strictEqual((ics.match(/BEGIN:VEVENT/g) || []).length, 6 + 1 + 6);        // 6 classes + quiz + 6 day-before reminders
  assert.ok(ics.includes('SUMMARY:QUIZ option visible: 5402 (G909)'));
  assert.ok(ics.includes('DTSTART:20260710T112000Z'));                              // Fri 10 Jul 2026 4:20 PM PKT = 11:20 UTC (the quiz class)
  assert.ok(ics.includes('DTSTART:20260706T104000Z') && ics.includes('DTEND:20260706T124000Z')); // Mon 3:40-5:40 PM
});

test('find by course code: one match opens straight away; several need a choice', () => {
  const { ids, errors } = boot(tmpBuild({ raw: PORTAL })); assert.deepStrictEqual(errors, []);
  assert.strictEqual(ids['wp-p-find'].style.display, 'block'); assert.strictEqual(ids['wp-p-paste'].style.display, 'none');
  ids['f-code'].value = '5402'; ids['f-go'].fire('click');
  assert.strictEqual(sessions(ids['wp-out']).length, 6);
  assert.strictEqual(sessions(ids['wp-out']).findIndex(r => r.className.includes('quiz')), 4);
  assert.strictEqual(webcal(ids).length, 1);
  ids['f-code'].value = '5402, 8422'; ids['f-go'].fire('click');
  const rows = find(ids, c => c.className.includes('wp-pub')); assert.strictEqual(rows.length, 2);
  rows.forEach(r => { r.all(c => c.tag === 'input')[0].checked = true; });
  find(ids, c => c.tag === 'button' && String(c.textContent).includes('Selected'))[0].fire('click');
  assert.strictEqual(sessions(ids['wp-out']).length, 12);
  ids['f-code'].value = '0000'; ids['f-go'].fire('click'); assert.ok(ids['f-msg'].className.includes('err'));
  ids['f-code'].value = ''; ids['f-sid'].value = ''; ids['f-go'].fire('click'); assert.ok(ids['f-msg'].textContent.includes('likhein'));
});

test('Student ID: classes load automatically, personal feed is built, nothing personal is published', () => {
  const o = { raw: PORTAL, roster: ROSTER_CSV };
  const dist = tmpBuild(o);
  const { ids, errors } = boot(dist); assert.deepStrictEqual(errors, []);
  ids['f-sid'].value = '000-000 0001'; ids['f-go'].fire('click');                      // spaces/dashes are normalised
  assert.ok(ids['f-msg'].textContent.includes('2 workshop'));
  assert.strictEqual(sessions(ids['wp-out']).length, 12);                              // 5402 + 8422, no click needed
  const key = Object.keys(o.rosterObj.entries).find(k => o.rosterObj.entries[k].length === 2);
  assert.ok(find(ids, c => c.tag === 'a' && String(c.href).endsWith('/calendar/u-' + key + '.ics')).length === 1, 'personal feed link');
  const personal = fs.readFileSync(path.join(dist, 'site/calendar/u-' + key + '.ics'), 'utf8');
  assert.strictEqual((personal.match(/SUMMARY:QUIZ option/g) || []).length, 2);
  ids['f-sid'].value = '0000000002'; ids['f-go'].fire('click'); assert.strictEqual(sessions(ids['wp-out']).length, 6);
  ids['f-sid'].value = '9999999999'; ids['f-code'].value = ''; ids['f-go'].fire('click'); assert.ok(ids['f-msg'].className.includes('err'));
  // privacy: the published files must not contain IDs, names or phone numbers
  for (const f of ['blogger/workshop-planner.html', 'site/tools/workshop-planner/index.html']) {
    const h = fs.readFileSync(path.join(dist, f), 'utf8');
    ['0000000001', '0000000002', 'Ali Khan', 'Sara Ahmed', '0300-0000001', '923000000001'].forEach(x => assert.ok(!h.includes(x), f + ' leaks ' + x));
  }
  assert.ok(!personal.includes('Ali Khan'));
});

test('Student ID without a roster explains what to do; no subscribe links without calendarBaseUrl', () => {
  const { ids } = boot(tmpBuild({ raw: PORTAL, base: '' }));
  ids['f-sid'].value = '0000000001'; ids['f-code'].value = ''; ids['f-go'].fire('click');
  assert.ok(ids['f-msg'].textContent.includes('auto-lookup abhi on nahi'));
  ids['f-code'].value = '5402'; ids['f-go'].fire('click');
  assert.strictEqual(sessions(ids['wp-out']).length, 6); assert.strictEqual(webcal(ids).length, 0);
});

test('manual workshops.json still works next to the portal paste; bad data fails the build clearly', () => {
  const sample = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/workshops.sample.json'), 'utf8'));
  const dist = tmpBuild({ raw: PORTAL, workshops: sample });
  assert.ok(fs.existsSync(path.join(dist, 'site/calendar/bs-english-sample.ics')));
  const { ids } = boot(dist); ids['f-code'].value = 'english'; ids['f-go'].fire('click');   // title search for manual entries
  assert.strictEqual(sessions(ids['wp-out']).length, 4);
  assert.throws(() => tmpBuild({ workshops: { workshops: [{ slug: 'x', title: 'X', sessions: [{ date: '2026-02-31', start: '10:00' }] }] } }), /bad date\/time/);
  assert.throws(() => tmpBuild({ workshops: { workshops: [{ slug: 'Bad Slug', title: 'X', sessions: [{ date: '2026-12-05', start: '10:00' }] }] } }), /bad slug/);
});

test('raw paste with no parsable line fails loudly (typo protection)', () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'aiou-')), 'raw.txt'); fs.writeFileSync(f, 'this is not a schedule\nneither is this');
  assert.throws(() => tmpBuild({ raw: f }), /koi class parse nahi hui/);
});

test('roster tool: CSV parsing, stable salt, hashed output, private coach page', () => {
  const r = RB.buildRoster('# comment\nStudent ID,Name,Phone,Course,Group\n"0001",Ali,"0300-1",5402,G909\n0001,Ali,0300-1,5402,G909\n,NoId,0300,1,G\n', null, 50);
  assert.strictEqual(Object.keys(r.entries).length, 1); assert.deepStrictEqual(Object.values(r.entries)[0], [['5402', 'G909']]); // header skipped, duplicate merged
  assert.strictEqual(r.problems.length, 1);
  const again = RB.buildRoster('0001,Ali,0300-1,5402,G909', { salt: r.salt, rounds: 50 }, null);
  assert.deepStrictEqual(Object.keys(again.entries), Object.keys(r.entries));                                        // same salt -> same key
  assert.ok(JSON.stringify({ salt: r.salt, entries: r.entries }).indexOf('Ali') === -1);
  const WL = require('../scripts/lib/workshops.js');
  const items = WL.load({ raw: PORTAL }).items;
  const html = RB.coachHtml(RB.buildRoster(ROSTER_CSV, null, 50), items, { brand: 'Taleemwaly' });
  assert.ok(html.includes('Ali Khan') && html.includes('923000000001') && html.includes('PRIVATE'));
  new vm.Script(html.match(/<script>([\s\S]*)<\/script>/)[1]);                                                         // page script is valid JS
  assert.ok(fs.readFileSync(path.join(ROOT, '.gitignore'), 'utf8').includes('private/'));
});
