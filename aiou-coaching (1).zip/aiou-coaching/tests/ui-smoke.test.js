/* Runs the built Course Advisor script against a tiny fake DOM to catch runtime errors. */
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

class El {
  constructor(tag) { this.tag = tag; this.children = []; this.listeners = {}; this.attrs = {}; this.style = {}; this.value = ''; this.checked = false; this._cls = new Set(); this._text = ''; this._html = ''; }
  get className() { return [...this._cls].join(' '); }
  set className(v) { this._cls = new Set(String(v).split(/\s+/).filter(Boolean)); }
  get classList() { const s = this._cls; return { add: c => s.add(c), remove: c => s.delete(c), toggle: c => (s.has(c) ? s.delete(c) : s.add(c)), contains: c => s.has(c) }; }
  appendChild(c) { this.children.push(c); return c; }
  get firstChild() { return this.children[0] || null; }
  set innerHTML(v) { this._html = v; if (v === '') this.children = []; }
  get innerHTML() { return this._html; }
  set textContent(v) { this._text = v; }
  get textContent() { return this._text; }
  addEventListener(e, fn) { (this.listeners[e] = this.listeners[e] || []).push(fn); }
  fire(e) { (this.listeners[e] || []).forEach(fn => fn.call(this, { target: this })); }
  setAttribute(k, v) { this.attrs[k] = v; }
  getAttribute(k) { return this.attrs[k]; }
  getElementsByTagName(t) { const out = []; (function walk(n) { n.children.forEach(c => { if (c.tag === t) out.push(c); walk(c); }); })(this); return out; }
  all(pred) { const out = []; (function walk(n) { n.children.forEach(c => { if (pred(c)) out.push(c); walk(c); }); })(this); return out; }
}

function boot(file) {
  const html = fs.readFileSync(path.join(__dirname, '..', file), 'utf8');
  const ids = {};
  for (const m of html.matchAll(/<(\w+)[^>]*\sid="([\w-]+)"/g)) ids[m[2]] = new El(m[1]);
  ids['a-mode'].value = 'any'; ids['a-sort'].value = 'match';
  const scripts = [...html.matchAll(/<script(?![^>]*\bsrc=)(?![^>]*ld\+json)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
  const doc = { readyState: 'complete', getElementById: id => ids[id] || null, createElement: t => new El(t), createTextNode: t => { const e = new El('#text'); e.textContent = t; return e; } };
  const errors = [];
  const ctx = { document: doc, window: { addEventListener() {}, prompt() {} }, navigator: {}, console, encodeURIComponent, parseFloat, Math, JSON, Object, Array, String, Number, setTimeout };
  vm.createContext(ctx);
  scripts.forEach(s => { try { vm.runInContext(s, ctx); } catch (e) { errors.push(e); } });
  return { ids, errors };
}

test('advisor boots and shows the intro prompt', () => {
  const { ids, errors } = boot('dist/blogger/course-advisor.html');
  assert.deepStrictEqual(errors, []);
  assert.ok(ids['a-out'].children[0].className.includes('adv-intro'));
  assert.ok(ids['a-qual'].children.length > 10, 'qualification options filled');
  assert.strictEqual(ids['a-subs'].children.length, 5);
  assert.ok(ids['a-cats'].children.length >= 8);
});

test('advisor renders cards, tabs, guidance and reacts to input', () => {
  const { ids, errors } = boot('dist/blogger/course-advisor.html');
  assert.deepStrictEqual(errors, []);
  ids['a-qual'].value = 'inter_premed'; ids['a-qual'].fire('change');
  ids['a-pct'].value = '72'; ids['a-pct'].fire('input');
  const out = ids['a-out'];
  const cards = out.all(c => c.className.includes('adv-card'));
  assert.ok(cards.length > 0 && cards.length <= 12, 'cards rendered: ' + cards.length);
  assert.ok(out.all(c => c.className.includes('adv-stat')).length >= 3, 'stat tabs');
  assert.ok(out.all(c => c.tag === 'details').length >= 6, 'guidance blocks');
  assert.strictEqual(ids['a-subs'].children[1].children[0].checked, true, 'physics auto-checked for pre-med');

  // switch tab, toggle interest chip, change qualification to ms
  out.all(c => c.className.includes('adv-stat') && c.className.includes('cond'))[0].fire('click');
  ids['a-cats'].children[0].fire('click');
  assert.ok(ids['a-cats'].children[0].classList.contains('on'));
  ids['a-qual'].value = 'ms'; ids['a-qual'].fire('change');
  assert.strictEqual(ids['w-cgpa'].style.display, 'block');
  assert.strictEqual(ids['w-subj'].style.display, 'block');
  ids['a-subj'].value = 'cs'; ids['a-cgpa'].value = '3.4'; ids['a-cgpa'].fire('input');
  assert.ok(ids['a-out'].all(c => c.tag === 'a' && String(c.href).startsWith('https://wa.me/')).length >= 1, 'WhatsApp link');
  ids['a-reset'].fire('click');
  assert.ok(ids['a-out'].children[0].className.includes('adv-intro'));
});

test('cover sheet and paper generator boot without errors', () => {
  for (const f of ['dist/blogger/cover-sheet.html', 'dist/blogger/paper-generator.html']) {
    const html = fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
    for (const m of html.matchAll(/<script(?![^>]*\bsrc=)(?![^>]*ld\+json)[^>]*>([\s\S]*?)<\/script>/g)) new vm.Script(m[1]);
  }
});

test('Blogger output is pure ASCII (Blogger turns non-ASCII into &#NNNN; which breaks JS strings)', () => {
  const dir = path.join(__dirname, '..', 'dist', 'blogger');
  for (const f of fs.readdirSync(dir)) {
    const buf = fs.readFileSync(path.join(dir, f));
    const bad = [...buf].filter(b => b > 127).length;
    assert.strictEqual(bad, 0, f + ' has ' + bad + ' non-ASCII bytes');
  }
});

test('decoded UI text has real characters, never literal HTML entities', () => {
  const { ids, errors } = boot('dist/blogger/course-advisor.html');
  assert.deepStrictEqual(errors, []);
  const texts = [];
  (function walk(n) { n.children.forEach(c => { texts.push(c.textContent); walk(c); }); })(ids['a-qual']);
  (function walk(n) { n.children.forEach(c => { texts.push(c.textContent); walk(c); }); })(ids['a-band']);
  (function walk(n) { n.children.forEach(c => { texts.push(c.textContent); walk(c); }); })(ids['a-cats']);
  assert.ok(texts.some(t => t.includes('\u2014')), 'em dash decoded');
  assert.ok(texts.some(t => t.includes('\u2013')), 'en dash decoded');
  assert.ok(texts.some(t => t.includes('\u{1F468}\u200D\u{1F3EB}')), 'ZWJ emoji decoded');
  assert.ok(texts.every(t => !/&#\d+;|&#x[0-9a-f]+;|\\u[0-9a-f]{4}/i.test(t)), 'no entity / escape leftovers');
  ids['a-qual'].value = 'inter_arts'; ids['a-qual'].fire('change');
  const all = []; (function walk(n) { n.children.forEach(c => { all.push(c.textContent); walk(c); }); })(ids['a-out']);
  assert.ok(all.some(t => t.includes('Gender & Women Studies')), 'ampersand decoded in program titles');
  assert.ok(all.every(t => !/&#\d+;|&amp;|\\u[0-9a-f]{4}/i.test(t)), 'no leftovers in results');
});
