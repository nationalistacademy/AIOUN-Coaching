/* AIOU Course Advisor — engine (pure functions, no DOM).
   Browser: ADV.toUser / ADV.run / ADV.advise      Node: require('./engine.js') */
var ADV = (function () {
  function byId(list, id) { for (var i = 0; i !== list.length; i++) { if (list[i].id === id) { return list[i]; } } return null; }
  function has(arr, x) { return !!arr && arr.indexOf(x) !== -1; }
  function fmt(n) { return 'Rs. ' + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function fieldLabel(meta, id) { var f = byId(meta.fields, id); if (f) { return f.label; } var s = byId(meta.subjectsStudied, id); return s ? s.label : id; }

  /* raw form values -> normalized user */
  function toUser(raw, meta) {
    var q = byId(meta.quals, raw.qual) || meta.quals[0];
    var u = { type: q.id, qual: q, rank: q.rank, pct: null, pctHi: null, pctApprox: false, cgpa: null,
      subj: raw.subj || '', subjects: (raw.subjects || []).slice(), mode: raw.mode || 'any',
      budget: raw.budget ? Number(raw.budget) : null, interests: (raw.interests || []).slice(), sort: raw.sort || 'match' };
    var p = parseFloat(raw.pct);
    if (!isNaN(p) && p >= 0 && p <= 100) { u.pct = p; u.pctHi = p; }
    else if (raw.band) {
      var b = byId(meta.bands, raw.band);
      if (b) { u.pct = b.lo; u.pctHi = b.hi; u.pctApprox = true; }
    }
    var c = parseFloat(raw.cgpa);
    if (!isNaN(c) && c > 0 && c <= 4) { u.cgpa = c; }
    if (!u.qual.needsSubj) { u.subj = ''; }
    return u;
  }

  /* check one program against one user */
  function evaluate(p, u, meta) {
    var g = meta.groups[p.g];
    var r = { st: 'ok', why: [], warn: [], p: p };
    function no(m) { r.st = 'no'; r.why.push(m); }
    function cn(m) { if (r.st === 'ok') { r.st = 'cond'; } r.warn.push(m); }
    var min = (p.min !== undefined) ? p.min : g.min;

    if (!g.addon && u.rank >= g.rank) {
      r.st = 'above';
      r.why.push('Aap pehle hi is level (' + g.label + ') ya us se upar ki qualification rakhte hain.');
      return r;
    }
    if (u.rank < min) { no('Kam az kam ' + meta.ranks[min] + ' qualification chahiye.'); return r; }

    if (p.ty) {
      var ok = has(p.ty, u.type), mx = 0, i;
      for (i = 0; i !== p.ty.length; i++) { var q = byId(meta.quals, p.ty[i]); if (q && q.rank > mx) { mx = q.rank; } }
      if (!ok && u.rank > mx) { ok = true; }
      if (!ok) { no('Is program ke liye ' + p.ty.map(function (t) { var x = byId(meta.quals, t); return x ? x.label : t; }).join(' ya ') + ' chahiye.'); }
    }
    if (p.p) {
      if (u.pct === null) { cn('Kam az kam ' + p.p + '% marks chahiye — apne marks / grade darj karein.'); }
      else if (u.pct >= p.p) { /* ok */ }
      else if (u.pctApprox && u.pctHi >= p.p) { cn('Aap ke grade band mein ' + p.p + '% ka imkaan hai — exact marks check karein.'); }
      else { no('Marks kam hain: ' + p.p + '% chahiye, aap ke ' + u.pct + '%.'); }
    }
    if (p.cg) {
      if (u.cgpa === null) { cn('CGPA ' + p.cg + '+ (ya equivalent division) chahiye — CGPA darj karein.'); }
      else if (u.cgpa < p.cg) { no('CGPA kam hai: ' + p.cg + ' chahiye, aap ka ' + u.cgpa + '.'); }
    }
    if (p.s) {
      var miss = p.s.filter(function (s) { return !has(u.subjects, s); });
      if (miss.length) { no('Zaroori subject: ' + miss.map(function (s) { return fieldLabel(meta, s); }).join(', ') + '.'); }
    }
    if (p.sa && !p.sa.some(function (s) { return has(u.subjects, s); })) {
      no('In mein se kam az kam ek subject chahiye: ' + p.sa.map(function (s) { return fieldLabel(meta, s); }).join(' / ') + '.');
    }
    if (p.ad) {
      if (u.type !== 'ad') { no('Is program ke liye relevant subject mein Associate Degree (AD) chahiye.'); }
      else if (!u.subj) { cn('Apne AD ka subject select karein.'); }
      else if (has(p.ad, u.subj)) { /* ok */ }
      else if (has(p.adc, u.subj)) { cn('Aap ka AD subject qareebi hai — admission office se confirm karein.'); }
      else { no('AD ka subject ' + fieldLabel(meta, p.ad[0]) + ' hona chahiye' + (u.subj ? ' (aap ka: ' + fieldLabel(meta, u.subj) + ')' : '') + '.'); }
    }
    if (p.ado && u.type === 'ad' && u.subj && u.subj === p.k) {
      cn('Same subject ke AD ke liye 60 credit hours se kam hona shart hai.');
    }
    if (p.dk && u.rank >= 4) {
      if (!u.subj) { cn('Apni degree ka subject select karein — relevant subject ki degree chahiye.'); }
      else if (u.subj !== p.k) { cn('Relevant subject ki degree chahiye — eligibility text dhyan se dekhein.'); }
    }
    if (r.st !== 'no') {
      if ((u.type === 'alevel' || u.type === 'dae') && min === 2) { cn('IBCC equivalence certificate lagana hoga.'); }
      if (p.x) { cn(p.n || 'Eligibility AIOU se confirm karein.'); }
    }
    return r;
  }

  /* evaluate everything, filter, rank */
  function run(data, u, meta) {
    var out = { ok: [], cond: [], no: [], above: [], over: [], hiddenMode: 0 };
    data.forEach(function (p) {
      if (u.mode !== 'any' && p.m !== u.mode) { out.hiddenMode++; return; }
      var r = evaluate(p, u, meta);
      var g = meta.groups[p.g];
      var base = r.st === 'ok' ? 200 : (r.st === 'cond' ? 100 : 0);
      var interest = has(u.interests, p.ct) ? 60 : 0;
      var step = g.addon ? 8 : Math.max(0, 10 - Math.abs(g.rank - u.rank - 1) * 4);
      r.score = base + interest + step;
      r.interest = interest > 0;
      if ((r.st === 'ok' || r.st === 'cond') && u.budget && p.f && p.f > u.budget) { out.over.push(r); return; }
      out[r.st].push(r);
    });
    var cmp = {
      match: function (a, b) { return (b.score - a.score) || ((a.p.f || 9e9) - (b.p.f || 9e9)); },
      fee: function (a, b) { return ((a.p.f || 9e9) - (b.p.f || 9e9)) || (b.score - a.score); },
      level: function (a, b) { return (meta.groups[b.p.g].rank - meta.groups[a.p.g].rank) || (b.score - a.score); }
    }[u.sort] || null;
    ['ok', 'cond', 'over'].forEach(function (k) { out[k].sort(cmp); });
    return out;
  }

  /* Roman-Urdu guidance blocks */
  function advise(u, res, meta, brand) {
    var B = [], q = u.qual, n1 = res.ok.length, n2 = res.cond.length;
    B.push({ t: '📌 Aap ki position', h: 'Aap ki qualification: <b>' + q.label + '</b>' + (u.pct !== null ? (u.pctApprox ? ' (grade band ~' + u.pct + '–' + u.pctHi + '%)' : ' (' + u.pct + '%)') : '') +
      '. Is ke mutabiq <b>' + n1 + '</b> programs mein seedha admission ban sakta hai aur <b>' + n2 + '</b> programs mein kuch shart confirm karni hogi.' });

    if (u.pct !== null) {
      var hi = u.pctApprox ? u.pctHi : u.pct;
      if (hi < 45) {
        B.push({ t: '📉 Marks ke hisab se mashwara', h: 'Zyada tar degree programs ki shart <b>45–50% marks</b> hoti hai, is liye aap ke options mehdood hain. Behtar raasta: jin certificates / open-course / HSSC-level programs mein marks ki shart nahi unse shuru karein, aur agar board allow kare to <b>improvement exam</b> se marks barhane ka sochein. Phir agle level par better programs khul jayenge.' });
      } else if (hi < 60) {
        B.push({ t: '📊 Marks ke hisab se mashwara', h: 'Aap ke marks zyada tar programs ki <b>45–50%</b> wali shart poori karte hain. Jin programs mein <b>60% ya CGPA</b> ki shart hai (jaise MS Computer Science, PhD) wahan nahi — baqi bohat se options khule hain.' });
      } else {
        B.push({ t: '💪 Marks ke hisab se mashwara', h: 'Aap ke marks achhe hain — marks ki wajah se koi program band nahi hona chahiye. Ab faisla <b>interest, career goal aur fee</b> par rakhein.' });
      }
    }

    var path = {
      0: 'Pehle <b>Matric (SSC)</b> karein (ya Dars-e-Nizami / Open Courses), phir <b>Intermediate</b>, uske baad Associate Degree ya BS. Beech mein koi Certificate course bhi kar sakte hain.',
      1: 'Aap ka agla qadam <b>Intermediate (HSSC)</b> hai — Pre-Medical / Pre-Engineering sirf <b>Matric Science</b> walon ke liye hai. Phir 2-saala <b>Associate Degree</b> ya seedha <b>4-saala BS</b>.',
      2: 'Aap ke paas 2 raaste hain: <b>(1)</b> seedha <b>4-saala BS</b>, ya <b>(2)</b> pehle 2-saala <b>Associate Degree</b> aur phir us ke baad <b>2-saala BS (AD based)</b> — dono ka total 4 saal hai, lekin AD beech mein ek degree de deta hai. Teaching mein jana ho to <b>ADE / B.Ed (4 saal)</b> dekhein.',
      3: 'AD / 14 saal ki degree ke baad: <b>2 – 2.5 saala BS</b>, <b>BBA</b>, <b>B.Ed (2–2.5 saal)</b> ya <b>PGD</b>. Agar aap ka AD kisi subject mein hai to usi subject ka BS (AD based) sab se seedha raasta hai.',
      4: '16 saal ke baad: <b>B.Ed (1.5 saal)</b>, <b>MBA</b>, <b>MPhil / MS</b> ya <b>PGD</b> aur short <b>Certificates</b>. MPhil / MS ke liye usi subject ki degree aur CGPA / division ki shart dekhein.',
      5: '18 saal ke baad: <b>PhD</b> (CGPA 3.0 / 1st division ki shart), ya apni skill ke liye <b>PGD / Certificates</b>.'
    }[u.rank];
    B.push({ t: '🧭 Aap ka raasta (pathway)', h: path });

    var top = res.ok.slice(0, 3);
    if (top.length) {
      B.push({ t: '⭐ Top picks', h: top.map(function (r) { return '<b>' + r.p.t + '</b> (' + r.p.c + ')' + (r.p.f ? ' — ' + fmt(r.p.f) : ''); }).join('<br>') +
        (u.interests.length ? '<br><small>Aap ki interests ko pehle rakha gaya hai.</small>' : '<br><small>Interest select karein to suggestions aur behtar hongi.</small>') });
    }
    var withFee = res.ok.filter(function (r) { return r.p.f; }).sort(function (a, b) { return a.p.f - b.p.f; });
    if (withFee.length) {
      B.push({ t: '💰 Fee planning', h: 'Sab se kam pehle-semester ki fee wala eligible option: <b>' + withFee[0].p.t + '</b> — ' + fmt(withFee[0].p.f) +
        '. Yeh sirf <b>pehle semester</b> ki fee hai; agle semesters, books/workshops ya exam ke alag kharche AIOU se confirm karein. Spring 2027 ki fee Autumn 2026 se mukhtalif ho sakti hai.' });
    }
    var docs = ['CNIC / B-Form ki copy', 'Pichli qualification ki marks sheet aur certificate', 'Passport-size tasweer'];
    if (u.type === 'alevel' || u.type === 'dae') { docs.push('<b>IBCC equivalence certificate</b> (A-Level / DAE / foreign qualification ke liye)'); }
    if (u.type === 'ad') { docs.push('AD ka transcript (credit hours likhe hon)'); }
    B.push({ t: '📄 Documents (aam tor par)', h: docs.join('<br>• ').replace(/^/, '• ') + '<br><small>Exact list AIOU ke admission notice mein dekhein.</small>' });
    B.push({ t: '📝 Admission ke steps', h: '1) AIOU ki official website par Spring 2027 admission notice / schedule dekhein.<br>2) Program select karke online form bharein aur documents upload karein.<br>3) Fee jama karwayen.<br>4) Admission confirm hone par books / LMS milti hain; phir <b>assignments</b> aur final exam.<br><small>Dates yahan nahi di gayi — woh sirf AIOU ke official notice se lein.</small>' });
    B.push({ t: '🤝 ' + (brand || 'Coaching') + ' se madad', h: 'Program chunne mein confusion ho, assignments ya tutor guidance chahiye to humse WhatsApp par rabta karein.' });
    return B;
  }

  var api = { toUser: toUser, evaluate: evaluate, run: run, advise: advise, fmt: fmt, byId: byId, fieldLabel: fieldLabel };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  return api;
})();
