#!/usr/bin/env node
/* Student roster tool.
     node scripts/roster.js roster.csv [--rounds 20000] [--coach private/coach-reminders.html]
   roster.csv columns:  student_id, name, phone, course_code, group     (header row optional; one row per student+course)

   Writes:
     data/roster.hashed.json  - SAFE to commit/publish: only iterated-hash keys + (course, group) pairs. No IDs, names, phones.
     private/coach-reminders.html (or --coach path) - LOCAL ONLY: today's / upcoming classes with one-click WhatsApp reminders.
                                                      Contains names and phone numbers; the folder is git-ignored. Never upload it. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const WS = require('../src/tools/workshop-planner/ics.js');
const WL = require('./lib/workshops.js');
const ROOT = path.resolve(__dirname, '..');

function parseCsv(text) {
  const rows = [];
  String(text).split(/\r?\n/).forEach(line => {
    if (!line.trim() || /^\s*#/.test(line)) return;
    const d = line.includes('\t') ? '\t' : ',';
    const cells = []; let cur = '', q = false;
    for (const ch of line) { if (ch === '"') q = !q; else if (ch === d && !q) { cells.push(cur.trim()); cur = ''; } else cur += ch; }
    cells.push(cur.trim()); rows.push(cells);
  });
  if (rows.length && /id/i.test(rows[0][0]) && !/\d{4,}/.test(rows[0][0])) rows.shift(); // header
  return rows;
}

function buildRoster(csvText, existing, rounds) {
  const salt = (existing && existing.salt) || crypto.randomBytes(16).toString('hex');
  rounds = rounds || (existing && existing.rounds) || 20000;
  const entries = {}, people = new Map(), problems = [];
  parseCsv(csvText).forEach((c, i) => {
    const [sid, name, phone, code, group] = c;
    if (!WS.normId(sid) || !code || !group) { problems.push('line ' + (i + 1) + ': student_id, course_code aur group zaroori hain'); return; }
    const key = WS.idKey(sid, salt, rounds);
    entries[key] = entries[key] || [];
    if (!entries[key].some(p => p[0] === code && p[1] === group)) entries[key].push([code, group]);
    if (!people.has(key)) people.set(key, { name: name || '', phone: WS.normPhone(phone) });
  });
  return { salt, rounds, entries, people, problems };
}

function coachHtml(roster, items, o) {
  const quizFromEnd = o.quizFromEnd === undefined ? 2 : o.quizFromEnd;
  const classes = [];
  items.forEach(it => {
    const enrolled = [];
    roster.people.forEach((p, key) => { if (roster.entries[key].some(e => e[0] === it.code && e[1] === it.group) && p.name + p.phone) enrolled.push([p.name, p.phone]); });
    if (!enrolled.length) return;
    WS.plan(WL.toSessions(it), { quizFromEnd })[0].sessions.forEach(s => classes.push({ t: it.title, d: s.date, st: s.start, n: s.n, tot: s.total, q: s.quiz ? 1 : 0, l: s.last ? 1 : 0, v: s.venue || '', e: enrolled }));
  });
  classes.sort((a, b) => (a.d + a.st).localeCompare(b.d + b.st));
  const data = JSON.stringify(classes).replace(/</g, '\\u003c');
  return `<!doctype html><html lang="ur"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Coach reminders (PRIVATE)</title>
<style>body{font-family:system-ui,Arial,sans-serif;max-width:860px;margin:20px auto;padding:0 14px;color:#222}h1{font-size:22px}.warn{background:#fff3cd;border:1px solid #ffe08a;padding:10px 14px;border-radius:10px;font-size:13px}
.bar{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}select,input{padding:8px;border:1px solid #ccc;border-radius:8px}.c{border:1px solid #e3e3e3;border-radius:14px;margin:12px 0;overflow:hidden}
.h{background:#f6f6f6;padding:10px 14px;font-weight:700}.h small{display:block;font-weight:400;color:#666}.r{display:flex;justify-content:space-between;gap:8px;padding:8px 14px;border-top:1px solid #eee;align-items:center}
a.b{background:#22a559;color:#fff;text-decoration:none;padding:6px 12px;border-radius:999px;font-size:13px}a.b.no{background:#bbb}.q{color:#2563eb;font-weight:700}</style></head><body>
<h1>Coach reminders - ${o.brand || ''}</h1><div class="warn">PRIVATE file: ismein students ke naam aur phone numbers hain. Isay upload / share na karein.</div>
<div class="bar"><label>Date: <input type="date" id="d"></label><label>Kitne din: <select id="n"><option value="1">Sirf is din</option><option value="2" selected>Is din + agla din</option><option value="3">3 din</option><option value="7">7 din</option></select></label></div><div id="o"></div>
<script>
var C=${data},B=${JSON.stringify(o.brand || '')};
var DN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],MN=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function p2(n){return(n<10?'0':'')+n}
function iso(t){return t.getUTCFullYear()+'-'+p2(t.getUTCMonth()+1)+'-'+p2(t.getUTCDate())}
function fd(i){var a=i.split('-'),t=new Date(Date.UTC(+a[0],+a[1]-1,+a[2]));return DN[t.getUTCDay()]+', '+p2(+a[2])+' '+MN[+a[1]-1]+' '+a[0]}
function f12(h){var x=+h.slice(0,2),s=x>=12?'PM':'AM';x=x%12||12;return x+':'+h.slice(3)+' '+s}
function msg(c,name){return 'Assalam o Alaikum'+(name?' '+name:'')+', yaad dahani: aap ki AIOU workshop '+c.t+' ki class '+c.n+'/'+c.tot+' '+fd(c.d)+' ko '+f12(c.st)+' par hai.'+(c.v?' ('+c.v+')':'')+(c.q?' Is class se quiz ka option (LMS par) visible ho jata hai - quiz zaroor attempt karein.':'')+(c.l?' Yeh aakhri class hai.':'')+(B?'\\n'+B:'')}
function go(){var from=document.getElementById('d').value,n=+document.getElementById('n').value,a=from.split('-'),end=iso(new Date(Date.UTC(+a[0],+a[1]-1,+a[2]+n-1))),o=document.getElementById('o');o.innerHTML='';var k=0;
C.forEach(function(c){if(c.d<from||c.d>end)return;k++;var d=document.createElement('div');d.className='c';var h=document.createElement('div');h.className='h';h.textContent=c.t+' - class '+c.n+'/'+c.tot;var s=document.createElement('small');s.textContent=fd(c.d)+', '+f12(c.st)+(c.q?'  |  QUIZ option visible':'')+(c.l?'  |  aakhri class':'');if(c.q)s.className='q';h.appendChild(s);d.appendChild(h);
c.e.forEach(function(e){var r=document.createElement('div');r.className='r';var t=document.createElement('span');t.textContent=e[0]||'(naam nahi)';r.appendChild(t);var a=document.createElement('a');a.className='b'+(e[1]?'':' no');a.textContent=e[1]?'WhatsApp reminder':'phone nahi';if(e[1]){a.href='https://wa.me/'+e[1]+'?text='+encodeURIComponent(msg(c,e[0]));a.target='_blank'}r.appendChild(a);d.appendChild(r)});o.appendChild(d)});
if(!k)o.textContent='Is muddat mein koi class nahi.'}
var t=new Date(Date.now()+5*3600000);document.getElementById('d').value=iso(t);document.getElementById('d').onchange=go;document.getElementById('n').onchange=go;go();
</script></body></html>`;
}

module.exports = { parseCsv, buildRoster, coachHtml };

if (require.main === module) {
  const args = process.argv.slice(2), csv = args.find(a => !a.startsWith('--') && fs.existsSync(a));
  if (!csv) { console.error('Usage: node scripts/roster.js roster.csv [--rounds 20000] [--coach private/coach-reminders.html]'); process.exit(1); }
  const flag = n => { const i = args.indexOf('--' + n); return i === -1 ? null : args[i + 1]; };
  const outJson = path.join(ROOT, 'data/roster.hashed.json');
  const existing = fs.existsSync(outJson) ? JSON.parse(fs.readFileSync(outJson, 'utf8')) : null;
  const r = buildRoster(fs.readFileSync(csv, 'utf8'), existing, flag('rounds') ? parseInt(flag('rounds'), 10) : 0);
  r.problems.forEach(p => console.warn('SKIPPED ' + p));
  fs.writeFileSync(outJson, JSON.stringify({ _note: 'Hashed lookup only - no student IDs, names or phones. Generated by scripts/roster.js', salt: r.salt, rounds: r.rounds, entries: r.entries }, null, 1) + '\n');
  const site = JSON.parse(fs.readFileSync(path.join(ROOT, 'config/site.json'), 'utf8'));
  const loaded = WL.load({ raw: path.join(ROOT, 'data/workshops-raw.txt'), manual: path.join(ROOT, 'data/workshops.json') });
  const known = new Set(loaded.items.map(i => i.code + '|' + i.group));
  let unknown = 0; Object.values(r.entries).forEach(l => l.forEach(p => { if (!known.has(p[0] + '|' + p[1])) unknown++; }));
  console.log(`Roster: ${Object.keys(r.entries).length} students, ${Object.values(r.entries).reduce((a, l) => a + l.length, 0)} enrollments -> data/roster.hashed.json (safe to commit)`);
  if (unknown) console.warn(`WARNING: ${unknown} enrollment(s) have a course/group that is not in the published schedule yet.`);
  const coachPath = path.resolve(ROOT, flag('coach') || 'private/coach-reminders.html');
  fs.mkdirSync(path.dirname(coachPath), { recursive: true });
  fs.writeFileSync(coachPath, coachHtml(r, loaded.items, { brand: site.brand, quizFromEnd: loaded.manual.quizFromEnd }));
  console.log('Coach page (PRIVATE, local only): ' + path.relative(ROOT, coachPath));
}
