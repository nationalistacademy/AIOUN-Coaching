const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const ADV = require('../src/tools/course-advisor/engine.js');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/aiou-programs.json'), 'utf8'));
const meta = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/aiou-meta.json'), 'utf8'));

function go(raw) { const u = ADV.toUser(raw, meta); return { u, res: ADV.run(data, u, meta) }; }
function find(res, serial) {
  for (const k of ['ok', 'cond', 'no', 'above', 'over']) { const r = res[k].find(x => x.p.i === serial); if (r) return { st: k, r }; }
  return null;
}
const bySerial = c => data.find(p => p.c === c).i;

test('dataset sanity', () => {
  assert.strictEqual(data.length, 225);
  const g = new Set(Object.keys(meta.groups));
  data.forEach(p => { assert.ok(g.has(p.g), 'unknown group ' + p.c); assert.ok(p.e, 'no eligibility ' + p.c); });
});

test('literate sees matric programs, not HSSC', () => {
  const { res } = go({ qual: 'literate' });
  assert.strictEqual(find(res, bySerial('2003')).st, 'ok');
  assert.strictEqual(find(res, bySerial('0332')).st, 'no');
});

test('Matric science vs arts: Pre-Medical HSSC', () => {
  const s = go({ qual: 'matric_sci' }).res, a = go({ qual: 'matric_arts' }).res;
  assert.strictEqual(find(s, bySerial('3003')).st, 'ok');
  assert.strictEqual(find(a, bySerial('3003')).st, 'no');
  assert.strictEqual(find(a, bySerial('0332')).st, 'ok');
});

test('Inter user: HSSC is "above", BS 4-year is open', () => {
  const { res } = go({ qual: 'inter_arts', pct: '55' });
  assert.strictEqual(find(res, bySerial('0332')).st, 'above');
  assert.strictEqual(find(res, bySerial('5058')).st, 'ok');
});

test('Pre-Medical cannot do BS Computer Science (needs Math) unless math studied', () => {
  const pm = go({ qual: 'inter_premed', pct: '75', subjects: ['physics', 'chem', 'bio'] }).res;
  assert.strictEqual(find(pm, bySerial('5117')).st, 'no');
  const withMath = go({ qual: 'inter_premed', pct: '75', subjects: ['physics', 'chem', 'bio', 'math'] }).res;
  assert.strictEqual(find(withMath, bySerial('5117')).st, 'ok');
  assert.strictEqual(find(pm, bySerial('5045')).st, 'ok'); // BS Microbiology needs bio
});

test('minimum marks: 50% for BS Computer Science', () => {
  const low = go({ qual: 'inter_ics', pct: '48', subjects: ['math', 'physics', 'comp'] }).res;
  assert.strictEqual(find(low, bySerial('5117')).st, 'no');
  const band = go({ qual: 'inter_ics', band: 'c', subjects: ['math'] }).res; // 50-59 -> lo 50
  assert.strictEqual(find(band, bySerial('5117')).st, 'ok');
  const edge = go({ qual: 'inter_ics', band: 'd', subjects: ['math'] }).res; // 45-49 can never reach 50
  assert.strictEqual(find(edge, bySerial('5117')).st, 'no');
  const none = go({ qual: 'inter_ics', subjects: ['math'] }).res; // marks not entered -> condition
  assert.strictEqual(find(none, bySerial('5117')).st, 'cond');
});

test('AD holder: same-subject BS (AD based) ok, other subject no', () => {
  const { res } = go({ qual: 'ad', pct: '65', subj: 'islamic' });
  assert.strictEqual(find(res, bySerial('5568')).st, 'ok');
  assert.strictEqual(find(res, bySerial('5602')).st, 'no'); // BS Urdu AD based
  assert.strictEqual(find(res, bySerial('5599')).st, 'ok'); // BS Economics BA/BSc based accepts AD other discipline
  assert.strictEqual(find(res, bySerial('5567')).st, 'ok'); // BS Arabic BA based accepts AD
});

test('AD holder in relevant discipline gets a condition on BA-based BS', () => {
  const { res } = go({ qual: 'ad', pct: '65', subj: 'english' });
  assert.strictEqual(find(res, bySerial('5596')).st, 'cond');
});

test('BA holder: 44% fails 45% programs', () => {
  const { res } = go({ qual: 'ba', pct: '44' });
  assert.strictEqual(find(res, bySerial('5596')).st, 'no');
  assert.strictEqual(find(res, bySerial('5641')).st, 'ok'); // Mass Comm: no % rule
});

test('BA holder cannot use BSc-only science BS', () => {
  const { res } = go({ qual: 'ba', pct: '70' });
  assert.strictEqual(find(res, bySerial('5580')).st, 'no');
  const bsc = go({ qual: 'bsc', pct: '70' }).res;
  assert.strictEqual(find(bsc, bySerial('5580')).st, 'ok');
});

test('16-year holder: B.Ed 1.5, PGD TEFL subject check, MPhil', () => {
  const eng = go({ qual: 'bs16', pct: '60', cgpa: '3.2', subj: 'english' }).res;
  assert.strictEqual(find(eng, bySerial('5008')).st, 'ok');
  assert.strictEqual(find(eng, bySerial('1302')).st, 'ok');
  assert.strictEqual(find(eng, bySerial('6201')).st, 'cond'); // Islamic Studies MPhil, different subject
  assert.strictEqual(find(eng, bySerial('5596')).st, 'above');
});

test('PhD needs CGPA 3.0', () => {
  const lo = go({ qual: 'ms', cgpa: '2.8', subj: 'islamic' }).res;
  assert.strictEqual(find(lo, bySerial('8204')).st, 'no');
  const hi = go({ qual: 'ms', cgpa: '3.5', subj: 'islamic' }).res;
  assert.strictEqual(find(hi, bySerial('8204')).st, 'ok');
});

test('budget moves programs to "over"; mode filter works', () => {
  const { res } = go({ qual: 'inter_arts', pct: '60', budget: '18000' });
  assert.ok(res.over.length > 0);
  assert.ok([...res.ok, ...res.cond].every(r => !r.p.f || r.p.f <= 18000));
  const odl = go({ qual: 'inter_premed', pct: '70', mode: 'ODL', subjects: ['bio'] }).res;
  assert.ok([...odl.ok, ...odl.cond, ...odl.no].every(r => r.p.m === 'ODL'));
});

test('interest ranks matching category first', () => {
  const { res } = go({ qual: 'inter_arts', pct: '60', interests: ['isl'] });
  assert.strictEqual(res.ok[0].p.ct, 'isl');
});

test('advise returns blocks for every qualification', () => {
  for (const q of meta.quals) {
    const { u, res } = go({ qual: q.id, pct: '60', subj: 'islamic' });
    const blocks = ADV.advise(u, res, meta, 'X');
    assert.ok(blocks.length >= 6, q.id);
  }
});
