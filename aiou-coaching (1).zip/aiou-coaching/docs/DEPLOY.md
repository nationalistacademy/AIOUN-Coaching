# Deploy karne ka tareeqa

## A) Blogger
`npm run build` ke baad `dist/blogger/` mein ye files milti hain:

| File | Blogger par kahan |
|---|---|
| `course-advisor.html` (≈73 KB) | **Page** → slug `course-advisor` |
| `workshop-planner.html` (≈36 KB) | **Page** → slug `workshop-planner` |
| `cover-sheet.html` (≈78 KB) | **Page** → slug `cover-sheet` |
| `paper-generator.html` (≈26 KB) | **Page** → slug `paper-generator` |
| `solved-assignments.html` (≈30 KB) | **Page** → slug `solved-assignments` |

Steps (har file ke liye):
1. Blogger → **Pages → New page**.
2. Editor mein upar-baen **pencil icon → HTML view** chunein.
3. Purana content delete karke file ka **poora content paste** karein.
4. **Settings → Posts → "Convert line breaks"** ko **No** rakhein (warna layout mein extra `<br>` aa sakte hain).
5. Publish. Page ka URL `…/p/<slug>.html` hona chahiye — `config/site.json` ka `siteUrl` aur Course Advisor button isi pattern par chalte hain.

Tips:
* Bade tools ko **Page** mein lagayen, sidebar **HTML/JavaScript gadget** mein nahi (gadget ki size limit ho sakti hai).
* Tools theme ke variables (`--bs-body-color`, `--jt-*`) use karte hain, is liye JetTheme ke light/dark mode ke saath khud match karte hain.
* Page ke title/post-header chhupane ka CSS solved-assignments page mein hai; baqi tools par zaroorat nahi.
* Agar Blogger koi script strip kare to **Theme → Edit HTML** ya **Layout** mein check karein ke "Allow scripts" wali koi setting/extension block to nahi kar rahi.

## B) GitHub Pages (standalone site)
1. GitHub par repo banayen, code `main` branch par push karein.
2. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Har push par workflow (`.github/workflows/deploy.yml`) build + test chalata hai aur `dist/site` publish karta hai. Fail ho to deploy nahi hota.
4. Site: `https://<username>.github.io/<repo>/` — hub page + `tools/…` + `solved-assignments/`.
5. Actions ke run mein `blogger-snippets` artifact bhi milta hai (taiyar Blogger files).

Custom domain chahiye to Pages settings mein domain add karein.

## C) Local
```bash
npm run build
npx serve dist/site     # ya koi bhi static server
```
