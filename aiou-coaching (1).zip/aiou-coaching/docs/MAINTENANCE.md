# Har semester ka kaam (Maintenance)

## Checklist (naya semester, maslan Spring 2027)
1. `config/site.json` → `semesterLabel` badlein (jaise `"Spring 2027 · Updated Weekly"`).
2. `data/solved-assignments.json` → bullets mein semester ka zikr (jaise "Spring 2026 + Autumn 2026") aur prices dekhein.
3. **AIOU ki nayi Eligibility & Fee PDF** aaye to:
   * Nayi PDF `data/source/` mein rakhein.
   * `data/aiou-meta.json` → `source` aur `sourceNote` update karein.
   * **Sirf fees badli hon:** CSV (`code,fee`) bana kar
     ```bash
     node scripts/update-fees.js fees.csv --dry   # pehle dekhein
     node scripts/update-fees.js fees.csv         # phir lagayen
     ```
   * **Naye programs / eligibility badli ho:** `data/aiou-programs.json` mein entry add/edit karein (neeche format).
4. `npm test` chalayen. Sab pass hone chahiye.
5. `dist/blogger/*.html` dobara Blogger pages mein paste karein (ya GitHub Pages khud deploy hota hai).

## `aiou-programs.json` ka format
Har program ek line:

```json
{"i":44,"c":"5058","t":"BS English","m":"ODL","g":"bs_hssc","f":20590,"e":"FA/F.Sc./…","ct":"hum","k":"english"}
```

| Key | Matlab |
|---|---|
| `i` | PDF ka serial number (unique id) |
| `c` / `t` | program code / title |
| `m` | `ODL` ya `F2F` |
| `g` | level group — `matric hssc adgen adsub bs_hssc bs_ba bs_ad bba bed pgd cert mphil phd` (`aiou-meta.json` → `groups`) |
| `f` | pehle semester ki fee (number, `null` agar PDF mein nahi) |
| `e` | AIOU ki eligibility ka text (user ko dikhta hai) |
| `ct` | interest category: `edu biz cs sci hum soc isl life gen` |
| `k` | program ka subject key (`aiou-meta.json` → `fields`) |
| `min` | kam az kam qualification rank (0 literate, 1 matric, 2 inter, 3 AD/BA, 4 16-saal, 5 MPhil) — group ka default override |
| `p` | kam az kam marks % |
| `cg` | kam az kam CGPA |
| `ty` | sirf in qualification types ko ijazat (jaise `["bsc"]`, `["matric_sci"]`); in se ooncha level bhi chalta hai |
| `s` | **saare** subjects zaroori (`["math"]`) |
| `sa` | in mein se **koi ek** subject (`["bio","math"]`) |
| `ad` / `adc` | zaroori AD subject / qareebi (⚠️ condition) AD subjects |
| `ado` | "AD kisi aur discipline ka ho" wali shart (same subject par ⚠️) |
| `dk` | degree ka subject relevant hona chahiye (MPhil/PhD wagaira) |
| `x` + `n` | ⚠️ condition flag aur uska note |
| `du` | muddat (agar group ki default se alag) |

Naya group/qualification/subject `data/aiou-meta.json` mein add karein, phir `tests/advisor.test.js` mein ek test.

## Data ke baare mein
* Data PDF se haath se structure kiya gaya (225 programs, serial PDF se match). PDF ke kuch typos theek kiye gaye (Phyics → Physics, Busniess → Business, …).
* PDF ki do jagah eligibility copy ho gayi thi (Associate Degree Statistics, Data Analytics) — in par ⚠️ note hai.
* AIOU ki PDF mein MA/MSc programs nahi hain, is liye tool unhe nahi dikhata.
