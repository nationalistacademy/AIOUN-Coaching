/* Workshop Planner - schedule parsing, quiz rule and calendar (.ics) engine. Pure functions, no DOM.
   Times are Pakistan time (Asia/Karachi, UTC+5, no DST) and are written to the calendar as UTC.
   Browser: global WS      Node: require('./ics.js') */
var WS = (function () {
  var TZ_OFFSET_H = 5;
  var MON = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  var DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var MONTH_FULL = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  /* ---------- dates & times ---------- */
  function mkDate(y, m, d) {
    var t = new Date(Date.UTC(y, m - 1, d));
    if (t.getUTCFullYear() !== y || t.getUTCMonth() !== m - 1 || t.getUTCDate() !== d) { return null; }
    return { y: y, m: m, d: d, iso: y + '-' + pad(m) + '-' + pad(d) };
  }
  function parseDate(s) {
    s = String(s === undefined || s === null ? '' : s).trim().replace(/^(mon|tue|wed|thu|fri|sat|sun)[a-z]*[,.\s]+/i, '');
    var m;
    if ((m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/))) { return mkDate(+m[1], +m[2], +m[3]); }
    if ((m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{2,4})$/))) { var y = +m[3]; if (y < 100) { y += 2000; } return mkDate(y, +m[2], +m[1]); } /* DD/MM/YYYY */
    if ((m = s.match(/^(\d{1,2})(?:st|nd|rd|th)?[\s\-\/.,]+([a-z]{3,9})[\s\-\/.,]+(\d{2,4})$/i))) {
      var mi = MON.indexOf(m[2].slice(0, 3).toLowerCase()); var yy = +m[3]; if (yy < 100) { yy += 2000; }
      return mi === -1 ? null : mkDate(yy, mi + 1, +m[1]);
    }
    if ((m = s.match(/^([a-z]{3,9})[\s\-.]+(\d{1,2})(?:st|nd|rd|th)?[,\s\-]+(\d{4})$/i))) {
      var mj = MON.indexOf(m[1].slice(0, 3).toLowerCase());
      return mj === -1 ? null : mkDate(+m[3], mj + 1, +m[2]);
    }
    return null;
  }
  function one(t) {
    var m = String(t).trim().toLowerCase().match(/^(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?$/);
    if (!m) { return null; }
    var h = +m[1], mi = m[2] ? +m[2] : 0, mer = m[3] ? m[3].replace(/\./g, '') : '';
    if (h > 23 || mi > 59) { return null; }
    return { h: h, mi: mi, mer: mer };
  }
  function to24(t, mer) {
    var h = t.h; if (mer === 'pm' && h < 12) { h += 12; } if (mer === 'am' && h === 12) { h = 0; }
    return h * 60 + t.mi;
  }
  function hhmm(min) { return pad(Math.floor(min / 60) % 24) + ':' + pad(min % 60); }
  function parseTimeRange(s) {
    s = String(s || '').toLowerCase().replace(/\s+to\s+/g, '-').replace(/[\u2013\u2014]/g, '-').trim();
    var parts = s.split('-').map(function (x) { return x.trim(); }).filter(Boolean);
    if (!parts.length || parts.length > 2) { return null; }
    var a = one(parts[0]), b = parts[1] ? one(parts[1]) : null;
    if (!a || (parts[1] && !b)) { return null; }
    var sMin, eMin = null;
    if (b) {
      eMin = to24(b, b.mer);
      if (a.mer) { sMin = to24(a, a.mer); }
      else if (b.mer) {
        sMin = to24(a, b.mer);
        if (sMin > eMin) { sMin = to24(a, b.mer === 'pm' ? 'am' : 'pm'); }
      } else { sMin = to24(a, ''); }
    } else { sMin = to24(a, a.mer); }
    return { start: hhmm(sMin), end: eMin === null ? null : hhmm(eMin) };
  }
  function looksLikeTime(c) { return /\d\s*(:|\.)\s*\d{2}|\d\s*(am|pm)\b/i.test(c) && parseTimeRange(c) !== null; }

  /* ---------- parse a pasted schedule ---------- */
  /* "Tuesday, July 7, 2026 3:40 PM" -> { date, hm } */
  function parseDateTime(s) {
    var m = String(s === undefined || s === null ? '' : s).trim().match(/^(.*?)[,\s]+(\d{1,2}[:.]\d{2}\s*(?:am|pm)?)$/i);
    if (!m) { return null; }
    var d = parseDate(m[1]), t = parseTimeRange(m[2]);
    return d && t ? { date: d, hm: t.start } : null;
  }
  var DT_RE = /[A-Za-z]+,\s+[A-Za-z]+\s+\d{1,2},\s+\d{4}\s+\d{1,2}:\d{2}\s*[AaPp][Mm]/g;
  var PIPE_CELL = /^[A-Za-z0-9]+\|[A-Za-z0-9]+(?:\|[A-Za-z0-9]+)?$/;

  /* Handles AIOU portal rows (course | code|group|batch | start datetime | end datetime), generic
     "date, time, title, venue" rows in any column order, tab/comma/pipe separated, or copied with spaces. */
  function parseSchedule(text, defaults) {
    defaults = defaults || {};
    var sessions = [], bad = [], header = null;
    String(text || '').split(/\r?\n/).forEach(function (line, i) {
      if (!line.trim() || /^\s*#/.test(line)) { return; }
      var d = null, cells, dts = [], pipe = null, date = null, tr = null, rest = [], restIdx = [];
      if (line.indexOf('\t') !== -1) { d = '\t'; }
      else if (/[A-Za-z0-9]\|[A-Za-z0-9]/.test(line)) { d = null; }
      else if (line.indexOf('|') !== -1) { d = '|'; }
      else if (line.indexOf(',') !== -1 && !/^\s*[A-Za-z]+ \d{1,2},\s*\d{4}/.test(line)) { d = ','; }
      if (d) { cells = line.split(d).map(function (x) { return x.trim().replace(/^"|"$/g, ''); }); }
      else {
        var ms = line.match(DT_RE) || [];
        ms.forEach(function (x) { var dt = parseDateTime(x); if (dt) { dts.push(dt); } });
        var pm = line.match(/([A-Za-z0-9]+)\|([A-Za-z0-9]+)(?:\|([A-Za-z0-9]+))?/);
        if (pm) { pipe = [pm[1], pm[2], pm[3] || '']; }
        cells = dts.length ? [] : [line.trim()];
      }
      cells.forEach(function (c, ci) {
        if (!c) { return; }
        var dt = parseDateTime(c);
        if (dt) { dts.push(dt); return; }
        if (PIPE_CELL.test(c)) { var p = c.split('|'); pipe = [p[0], p[1], p[2] || '']; return; }
        var pd = !date ? parseDate(c) : null;
        if (pd) { date = pd; return; }
        if (!tr && looksLikeTime(c)) { tr = parseTimeRange(c); return; }
        rest.push(c); restIdx.push(ci);
      });
      if (dts.length) { date = dts[0].date; tr = { start: dts[0].hm, end: dts[1] && dts[1].date.iso === dts[0].date.iso ? dts[1].hm : null }; }
      if (!date && !tr) { if (!header && cells.length > 1) { header = cells.map(function (c) { return c.toLowerCase(); }); } else { bad.push({ line: i + 1, why: 'Date / time nahi mila' }); } return; }
      if (!date) { bad.push({ line: i + 1, why: 'Date samajh nahi aayi (DD/MM/YYYY ya 12-Dec-2026 likhein)' }); return; }
      if (!tr) { if (defaults.start) { tr = { start: defaults.start, end: defaults.end || null }; } else { bad.push({ line: i + 1, why: 'Time nahi mila (jaise 10:00 AM - 12:00 PM)' }); return; } }
      var title = '', venue = '', code = '', group = '', batch = '';
      if (pipe) { code = pipe[0]; group = pipe[1]; batch = pipe[2]; title = code + ' (' + group + ')'; rest = rest.filter(function (c) { return c !== code; }); restIdx = restIdx.slice(0, rest.length); }
      rest.forEach(function (c, k) {
        var h = header ? (header[restIdx[k]] || '') : '';
        if (/venue|location|link|room|centre|center|place/.test(h)) { venue = venue || c; }
        else if (!title) { title = c; }
        else if (!venue) { venue = c; }
      });
      var o = { title: title || defaults.title || 'Workshop', date: date.iso, start: tr.start, end: tr.end, venue: venue || defaults.venue || '' };
      if (code) { o.code = code; o.group = group; o.batch = batch; }
      sessions.push(o);
    });
    return { sessions: sessions, bad: bad };
  }

  /* ---------- quick builder ---------- */
  function addDays(iso, n) { var p = iso.split('-'); var t = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2] + n)); return t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate()); }
  function weekday(iso) { var p = iso.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay(); }
  function generateSessions(o) {
    var out = [], skip = o.skip || [], first = o.startDate, wd0 = weekday(first), n = Math.max(0, Math.min(60, +o.count || 0));
    for (var i = 0; i !== 500 && out.length !== n; i++) {
      var iso = addDays(first, i), wd = weekday(iso);
      var ok = o.pattern === 'daily' ? true : (o.pattern === 'weekdays' ? (wd !== 0 && wd !== 6) : (o.pattern === 'custom' ? (o.days || []).indexOf(wd) !== -1 : wd === wd0));
      if (ok && skip.indexOf(iso) === -1) { out.push({ title: o.title || 'Workshop', date: iso, start: o.start, end: o.end || null, venue: o.venue || '' }); }
    }
    return out;
  }

  /* ---------- plan: group by workshop, number sessions, apply the quiz rule ---------- */
  function plan(sessions, opts) {
    opts = opts || {};
    var fromEnd = opts.quizFromEnd === undefined ? 2 : opts.quizFromEnd, dur = opts.durationMin || 120;
    var groups = {}, order = [];
    sessions.slice().sort(function (a, b) { return (a.date + a.start).localeCompare(b.date + b.start); }).forEach(function (s) {
      if (!groups[s.title]) { groups[s.title] = []; order.push(s.title); }
      groups[s.title].push(s);
    });
    return order.map(function (t) {
      var list = groups[t], total = list.length;
      var qi = (fromEnd > 0 && total >= 2 && fromEnd <= total) ? total - fromEnd + 1 : 0;
      return { title: t, code: list[0].code || '', group: list[0].group || '', batch: list[0].batch || '', sessions: list.map(function (s, i) {
        var st = utcMs(s.date, s.start), en = s.end ? utcMs(s.date, s.end) : st + dur * 60000;
        if (en <= st) { en = st + dur * 60000; }
        return { n: i + 1, total: total, title: t, date: s.date, start: s.start, end: msToHm(en),
          venue: s.venue || '', startMs: st, endMs: en, quiz: i + 1 === qi, last: i + 1 === total };
      }) };
    });
  }
  function utcMs(iso, hm) { var p = iso.split('-'), t = hm.split(':'); return Date.UTC(+p[0], +p[1] - 1, +p[2], +t[0] - TZ_OFFSET_H, +t[1]); }
  function msToHm(ms) { var d = new Date(ms + TZ_OFFSET_H * 3600000); return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); }
  function fmtUtc(ms) { var d = new Date(ms); return d.getUTCFullYear() + pad(d.getUTCMonth() + 1) + pad(d.getUTCDate()) + 'T' + pad(d.getUTCHours()) + pad(d.getUTCMinutes()) + pad(d.getUTCSeconds()) + 'Z'; }

  /* ---------- labels ---------- */
  function fmtDay(iso) { var p = iso.split('-'); return DAYS[weekday(iso)] + ', ' + pad(+p[2]) + ' ' + MONTH_FULL[+p[1] - 1] + ' ' + p[0]; }
  function fmt12(hm) { var h = +hm.slice(0, 2), m = hm.slice(3), s = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return h + ':' + m + ' ' + s; }
  function offsetLabel(m) { if (m % 1440 === 0) { return (m / 1440) + ' din'; } if (m % 60 === 0) { return (m / 60) + ' ghanta'; } return m + ' minute'; }

  /* ---------- events ---------- */
  function hash(str) { var h = 5381; for (var i = 0; i !== str.length; i++) { h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; } return h.toString(16); }
  function sessionDesc(s, brand) {
    var L = ['AIOU Workshop: ' + s.title, 'Session ' + s.n + ' / ' + s.total, s.venue ? 'Venue / Link: ' + s.venue : '', ''];
    if (s.quiz) { L.push('QUIZ: Is class se quiz ka option (LMS par) visible ho jata hai - class ke baad quiz attempt karna na bhoolein.'); }
    if (s.last) { L.push('Yeh is workshop ki aakhri class hai.'); }
    L.push('Schedule ki tasdeeq AIOU portal / LMS se karein.'); if (brand) { L.push(brand); }
    return L.filter(function (x, i) { return x !== '' || i === 3; }).join('\n');
  }
  /* opts: reminders [minutes], safe [minutes], brand, sequence */
  function events(pl, opts) {
    opts = opts || {}; var out = [], rem = opts.reminders || [], safe = opts.safe || [];
    pl.forEach(function (w) {
      w.sessions.forEach(function (s) {
        var tag = s.quiz ? ' [Quiz option visible]' : (s.last ? ' [Last class]' : '');
        out.push({ uid: hash('s|' + w.title + '|' + s.date + '|' + s.start) + '@aiou-coaching', start: s.startMs, end: s.endMs,
          summary: 'AIOU Workshop: ' + w.title + ' (' + s.n + '/' + s.total + ')' + tag, desc: sessionDesc(s, opts.brand), loc: s.venue, alarms: rem, kind: 'session', s: s });
        if (s.quiz) {
          out.push({ uid: hash('q|' + w.title + '|' + s.date + '|' + s.start) + '@aiou-coaching', start: s.startMs, end: s.startMs + 15 * 60000,
            summary: 'QUIZ option visible: ' + w.title, desc: 'AIOU workshop "' + w.title + '" ki ' + s.n + '/' + s.total + ' class (2nd last) se quiz ka option visible ho jata hai.\nLMS khol kar quiz attempt karein.', loc: s.venue, alarms: [0, 60], kind: 'quiz', s: s });
        }
        safe.forEach(function (m) {
          out.push({ uid: hash('r' + m + '|' + w.title + '|' + s.date + '|' + s.start) + '@aiou-coaching', start: s.startMs - m * 60000, end: s.startMs - m * 60000 + 15 * 60000,
            summary: 'Reminder: ' + w.title + ' workshop ' + offsetLabel(m) + ' baad', desc: 'Workshop ' + fmtDay(s.date) + ' ko ' + fmt12(s.start) + ' par hai.' + (s.venue ? '\n' + s.venue : ''), loc: s.venue, alarms: [0], kind: 'reminder', s: s });
        });
      });
    });
    return out;
  }

  /* ---------- ICS text ---------- */
  function esc(t) { return String(t || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n'); }
  function utf8len(ch) { var c = ch.codePointAt(0); return c < 0x80 ? 1 : (c < 0x800 ? 2 : (c < 0x10000 ? 3 : 4)); }
  function fold(line) {
    var out = [], cur = '', n = 0, limit = 75;
    Array.from(line).forEach(function (ch) {
      var l = utf8len(ch);
      if (n + l > limit) { out.push(cur); cur = ' ' + ch; n = 1 + l; limit = 75; } else { cur += ch; n += l; }
    });
    out.push(cur); return out.join('\r\n');
  }
  function buildIcs(evs, o) {
    o = o || {}; var stamp = fmtUtc(o.now ? o.now.getTime() : Date.now());
    var L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//AIOU Coaching//Workshop Planner//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH',
      'X-WR-CALNAME:' + esc(o.name || 'AIOU Workshops'), 'X-WR-TIMEZONE:Asia/Karachi', 'REFRESH-INTERVAL;VALUE=DURATION:PT6H', 'X-PUBLISHED-TTL:PT6H'];
    evs.forEach(function (e) {
      L.push('BEGIN:VEVENT', 'UID:' + e.uid, 'DTSTAMP:' + stamp, 'SEQUENCE:' + (o.sequence || 0), 'DTSTART:' + fmtUtc(e.start), 'DTEND:' + fmtUtc(e.end),
        'SUMMARY:' + esc(e.summary), 'DESCRIPTION:' + esc(e.desc));
      if (e.loc) { L.push('LOCATION:' + esc(e.loc)); }
      L.push('CATEGORIES:AIOU,Workshop', 'STATUS:CONFIRMED', 'TRANSP:OPAQUE');
      (e.alarms || []).forEach(function (m) {
        L.push('BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:' + esc(e.summary), 'TRIGGER:' + (m === 0 ? 'PT0S' : '-PT' + m + 'M'), 'END:VALARM');
      });
      L.push('END:VEVENT');
    });
    L.push('END:VCALENDAR');
    return L.map(fold).join('\r\n') + '\r\n';
  }
  function googleLink(e) {
    return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' + encodeURIComponent(e.summary) + '&dates=' + fmtUtc(e.start) + '/' + fmtUtc(e.end) +
      '&details=' + encodeURIComponent(e.desc) + (e.loc ? '&location=' + encodeURIComponent(e.loc) : '') + '&ctz=Asia%2FKarachi';
  }


  /* ---------- hashed student-ID lookup (pure JS SHA-256, iterated) ---------- */
  var SH = (function () {
    var P = [], n = 2; while (P.length !== 64) { var pr = true; for (var j = 2; j * j <= n; j++) { if (n % j === 0) { pr = false; break; } } if (pr) { P.push(n); } n++; }
    var fr = function (x) { return Math.floor((x - Math.floor(x)) * 4294967296) >>> 0; };
    return { K: P.map(function (p) { return fr(Math.cbrt(p)); }), H: P.slice(0, 8).map(function (p) { return fr(Math.sqrt(p)); }) };
  })();
  function sha256(bytes) {
    var H = SH.H.slice(), K = SH.K, l = bytes.length, total = (((l + 9 + 63) >> 6) << 6), buf = new Uint8Array(total), i, t;
    buf.set(bytes); buf[l] = 0x80;
    var bits = l * 8; buf[total - 4] = (bits >>> 24) & 255; buf[total - 3] = (bits >>> 16) & 255; buf[total - 2] = (bits >>> 8) & 255; buf[total - 1] = bits & 255;
    var w = new Array(64);
    function rr(x, c) { return (x >>> c) | (x << (32 - c)); }
    for (var off = 0; off !== total; off += 64) {
      for (i = 0; i !== 16; i++) { w[i] = ((buf[off + i * 4] << 24) | (buf[off + i * 4 + 1] << 16) | (buf[off + i * 4 + 2] << 8) | buf[off + i * 4 + 3]) >>> 0; }
      for (i = 16; i !== 64; i++) {
        var s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i !== 64; i++) {
        var S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
        var S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = (S0 + mj) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0; H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
    }
    var out = new Uint8Array(32); for (t = 0; t !== 8; t++) { out[t * 4] = H[t] >>> 24; out[t * 4 + 1] = (H[t] >>> 16) & 255; out[t * 4 + 2] = (H[t] >>> 8) & 255; out[t * 4 + 3] = H[t] & 255; }
    return out;
  }
  function normId(id) { return String(id === undefined || id === null ? '' : id).replace(/[^0-9A-Za-z]/g, '').toUpperCase(); }
  /* iterated SHA-256 (slows brute-forcing of 10-digit IDs); returns a 16-hex-char key */
  function idKey(id, salt, rounds) {
    var s = String(salt) + ':' + normId(id), b = new Uint8Array(s.length); for (var i = 0; i !== s.length; i++) { b[i] = s.charCodeAt(i) & 255; }
    var h = sha256(b); for (var r = 1; r < rounds; r++) { h = sha256(h); }
    var hex = ''; for (var k = 0; k !== 8; k++) { hex += pad16(h[k]); } return hex;
  }
  function pad16(n) { return (n < 16 ? '0' : '') + n.toString(16); }
  function normPhone(p) { var d = String(p || '').replace(/\D/g, ''); if (d.indexOf('00') === 0) { d = d.slice(2); } if (d.charAt(0) === '0') { d = '92' + d.slice(1); } else if (d.length === 10 && d.charAt(0) === '3') { d = '92' + d; } return d; }

  /* ---------- WhatsApp / student message (Roman Urdu) ---------- */
  function message(pl, o) {
    o = o || {}; var L = ['Assalam o Alaikum' + (o.student ? ' ' + o.student : '') + ',', 'Aap ke AIOU workshop ka schedule:', ''];
    pl.forEach(function (w) {
      L.push('*' + w.title + '*');
      w.sessions.forEach(function (s) {
        L.push(s.n + ') ' + fmtDay(s.date) + ', ' + fmt12(s.start) + ' - ' + fmt12(s.end) + (s.venue ? ' (' + s.venue + ')' : '') + (s.quiz ? '  << QUIZ option visible' : '') + (s.last ? '  << aakhri class' : ''));
      });
      L.push('');
    });
    if ((o.reminders || []).length) { L.push('Reminders: ' + o.reminders.map(offsetLabel).join(', ') + ' pehle.'); }
    L.push('Quiz ka option workshop ki 2nd last class se visible ho jata hai - LMS check karte rahein.');
    if (o.brand) { L.push('', o.brand); }
    return L.join('\n');
  }

  var api = { parseDateTime: parseDateTime, sha256: sha256, idKey: idKey, normId: normId, normPhone: normPhone, parseDate: parseDate, parseTimeRange: parseTimeRange, parseSchedule: parseSchedule, generateSessions: generateSessions, plan: plan, events: events,
    buildIcs: buildIcs, googleLink: googleLink, message: message, fmtUtc: fmtUtc, fmtDay: fmtDay, fmt12: fmt12, offsetLabel: offsetLabel, utcMs: utcMs, addDays: addDays, weekday: weekday };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  return api;
})();
